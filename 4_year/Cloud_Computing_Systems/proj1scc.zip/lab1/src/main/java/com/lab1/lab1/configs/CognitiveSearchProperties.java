package com.lab1.lab1.configs;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
@Getter
@Setter
@ConfigurationProperties("azure.search")
public class CognitiveSearchProperties {

    private String endpoint, key, index;
}