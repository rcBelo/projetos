package com.lab1.lab1.configs;

import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import com.azure.storage.common.StorageSharedKeyCredential;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableConfigurationProperties(StorageProperties.class)
public class StorageConfig {
    private StorageProperties properties;

    public StorageConfig(StorageProperties prop) {
        properties = prop;
    }

    @Bean
    public BlobServiceClient serviceClient() {
        return new BlobServiceClientBuilder()
                .endpoint(String.format("https://%s.blob.core.windows.net/", properties.getName()))
                .credential(new StorageSharedKeyCredential(properties.getName(), properties.getKey())).buildClient();

    }

}
