package com.lab1.lab1.configs;

import javax.validation.constraints.NotEmpty;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@ConfigurationProperties("azure.storage")
public class StorageProperties {
    @NotEmpty
    private String name, key;

}
