package com.lab1.lab1.controllers;

import java.util.List;

import com.lab1.lab1.services.MediaService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/rest/media")
public class MediaController extends AbstractController {
    @Autowired
    private MediaService service;

    @PostMapping
    public ResponseEntity<String> upload(@RequestBody byte[] contents) {
        return ok(service.upload(contents));
    }

    @GetMapping("/{key}")
    public ResponseEntity<byte[]> download(@PathVariable String key) {
        return ok(service.download(key));
    }
    @GetMapping
    public ResponseEntity<List<String>> list() {
        return ok(service.list());
    }
}
