package com.lab1.lab1.controllers;


import com.lab1.lab1.dtos.msgDTO;
import com.lab1.lab1.services.msgService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/rest/messages")
public class MessagesController extends AbstractController{

    @Autowired
    private msgService msg;

    @GetMapping("/{id}")
    public ResponseEntity<msgDTO> getMessage(@PathVariable String id) {
        return ok(msg.getMessage(id));
        
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMessage(@PathVariable String id) {
        return ok(msg.deleteMessage(id));

    }

   
   

 @PostMapping
    public ResponseEntity<String> addMessage(@RequestBody msgDTO DTO) {
        return ok(msg.addMessage(DTO));
      
        
    }
    
}
