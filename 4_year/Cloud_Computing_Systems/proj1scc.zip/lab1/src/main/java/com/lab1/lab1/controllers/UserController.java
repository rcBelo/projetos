package com.lab1.lab1.controllers;

import java.security.Principal;
import java.util.HashSet;
import java.util.concurrent.ExecutionException;

import com.lab1.lab1.daos.UserDAO;
import com.lab1.lab1.dtos.UpdateUserDTO;
import com.lab1.lab1.dtos.UserDTO;
import com.lab1.lab1.dtos.loginDTO;
import com.lab1.lab1.services.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@RestController
@RequestMapping("/rest/user")
public class UserController extends AbstractController{

    @Autowired
    private UserService service;

     
     @PostMapping
     public ResponseEntity<UserDAO> registerUser(@RequestBody UserDTO u) {
        return ok(service.register(new UserDAO(u)));

    }
    @PutMapping("/logout")
    public ResponseEntity<Void> logout( HttpServletResponse response){
         return ok(service.logout(response));
    }


    @PutMapping("/login")
    public ResponseEntity<Void> login(@RequestBody loginDTO user, HttpServletResponse response) {
        return ok(service.login(user.getUsername(), user.getPwd(),response));

    }
    
     @GetMapping("/{userId}")
     public ResponseEntity<UserDTO> getUser(@PathVariable String userId) throws ExecutionException, InterruptedException {
        return ok(service.getUserOptional(userId));
        
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable String id) {
        return ok(service.deleteUser(id));
        
    }

   
   
    @PutMapping
    public ResponseEntity<UserDTO> updateUser(@RequestBody UpdateUserDTO updatedUser, Authentication auth) {
       return ok(service.updateUser(updatedUser, auth));
        
    }

    @PutMapping("/subscribe/{channelId}")
    public ResponseEntity<Void> subscribeChannel(Authentication auth,@PathVariable String channelId) {
        return ok(service.subscribeChannel(auth, channelId));
        
    }

    @PutMapping("/unSubscribe/{channelId}")
    public ResponseEntity<Void> unSubscribeChannel(Authentication auth,@PathVariable String channelId) {
        return ok(service.unSubscribeChannel(auth, channelId));

    }

    @GetMapping("/channels/own")
    public ResponseEntity<HashSet<String>> getUserChannels(){
         return ok(service.getUserChannels());
    }

    
}
