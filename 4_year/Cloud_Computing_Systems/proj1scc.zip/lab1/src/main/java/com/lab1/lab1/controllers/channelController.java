package com.lab1.lab1.controllers;

import com.lab1.lab1.daos.channelDAO;
import com.lab1.lab1.daos.msgDAO;
import com.lab1.lab1.dtos.UpdateChannelDTO;
import com.lab1.lab1.dtos.channelDTO;
import com.lab1.lab1.dtos.createChannelDTO;
import com.lab1.lab1.dtos.msgDTO;
import com.lab1.lab1.services.channelServices;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/rest/channel")
public class channelController extends AbstractController{

    @Autowired
    private channelServices service;

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteChannels(@PathVariable String id) {
        return ok(service.deleteChannels(id));
        
    }
    @GetMapping("/{id}")
    public ResponseEntity<channelDTO> getChannel(@PathVariable String id) {
       return ok(service.getChannelOptional(id));
    }


   @PostMapping
    public ResponseEntity<channelDTO> createChannels(@RequestBody createChannelDTO channel, Authentication auth) {
        System.out.println(channel);
       return ok(service.createChannels(channel,auth));
    }

    @PutMapping
    public ResponseEntity<channelDTO> updateChannel(@RequestBody UpdateChannelDTO channel) {
        return ok(service.updateChannel(channel));
    }
    @PutMapping("/{id}/addMember/{userId}")
    public ResponseEntity<channelDTO> addMember(@PathVariable String id,@PathVariable String userId) {
        return ok(service.addMember(id, userId));
    }
    @PutMapping("/{id}/removeMember/{userId}")
    public ResponseEntity<channelDTO> removeMember(@PathVariable String id,@PathVariable String userId) {
        return ok(service.removeMember(id, userId));
    }
     @GetMapping("/{id}/messages")
    public ResponseEntity<Page<msgDTO>> getChannelMessages(@RequestParam(value="num",defaultValue = "0") int num,@RequestParam(value = "len",defaultValue = "10") int len,@PathVariable String id) throws ExecutionException, InterruptedException {
        return ok(service.getChannelMessages(num,len,id).get());
    }
    @GetMapping("/{id}/messages/search/{text}")
    public ResponseEntity<Page<msgDTO>> getChannelMessagesTextSearch(@RequestParam(value="num",defaultValue = "0") int num,@RequestParam(value = "len",defaultValue = "10") int len,
                                                                     @PathVariable String id,@PathVariable String text) throws ExecutionException, InterruptedException {
       return ok(service.getChannelMessagesTextSearch(num,len,id,text).get());

    }


 
    
}
