package com.lab1.lab1.daos;

import java.util.LinkedList;
import java.util.List;
import java.util.UUID;

import com.azure.spring.data.cosmos.core.mapping.Container;
import com.lab1.lab1.dtos.UpdateChannelDTO;
import com.lab1.lab1.dtos.channelDTO;

import com.lab1.lab1.dtos.createChannelDTO;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
@Container(containerName="Channel",ru = "400")
@NoArgsConstructor
public class channelDAO {
    @Id
	private String id;
    private String name;
    private boolean privateChannel;
    private String ownerId;
    private List<String> members;
    

    public channelDAO(createChannelDTO channel, String ownerId) {
        id = UUID.randomUUID().toString();
        this.name = channel.getName();
        this.privateChannel = channel.isPrivateChannel();
        this.ownerId = ownerId;
        if (channel.getMembers() == null){
            this.members = new LinkedList<String>();
        }else{
            this.members = channel.getMembers();
        }

    }
     
    public void update(UpdateChannelDTO newChannelInfo) {
        if (newChannelInfo.getName() != null) {
            this.name = newChannelInfo.getName();
        }
    }
}
