package com.lab1.lab1.daos;

import lombok.AllArgsConstructor;
import lombok.Data;

import com.azure.spring.data.cosmos.core.mapping.Container;
import com.lab1.lab1.dtos.msgDTO;

import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;

import java.util.UUID;

@Data
@Container(containerName="Message",ru = "400")
@NoArgsConstructor
@AllArgsConstructor
public class msgDAO {
    @Id
    private String id;
    private String replyTo;
    private String channel;
    private String user;
    private String text;
    private String imageId;
    private Long creationDate;

    public msgDAO(msgDTO DTO, UserDAO user){
        this.id = UUID.randomUUID().toString();
        this.creationDate=System.currentTimeMillis();
        this.replyTo = DTO.getReplyTo();
        this.channel = DTO.getChannel();
        this.user = user.getId();
        this.imageId = DTO.getImageId();
        this.text = DTO.getText();

    }
    
}
