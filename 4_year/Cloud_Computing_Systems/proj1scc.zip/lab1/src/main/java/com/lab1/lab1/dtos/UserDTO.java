package com.lab1.lab1.dtos;

import java.io.Serializable;
import java.util.HashSet;

import com.lab1.lab1.daos.UserDAO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserDTO implements Serializable {
    private String pwd;
    private String id;
    private String imageId;
    @NotEmpty
    private String name,username;
    private HashSet<String> channelIds;

    public UserDTO(UserDAO dao){
        this.name=dao.getName();
        this.id=dao.getId();
        this.channelIds=dao.getChannelIds();
        this.imageId = dao.getImageId();
        this.username = dao.getUsername();
    }
}

