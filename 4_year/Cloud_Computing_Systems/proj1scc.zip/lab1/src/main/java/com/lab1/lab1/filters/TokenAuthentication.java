package com.lab1.lab1.filters;

import com.lab1.lab1.daos.UserDAO;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.web.authentication.WebAuthenticationDetails;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;

public class TokenAuthentication implements Authentication {

    private static final long serialVersionUID = -3305389715334779629L;

    private final UserDAO principal;
    private final List<? extends GrantedAuthority> auth;
    private boolean isAuth = true;
    private Object details;

    public TokenAuthentication(UserDAO user) {
        this.principal = user;
        this.auth = Arrays.asList();
    }

    @Override
    public String getName() {
        return principal.getUsername();
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return auth;
    }

    @Override
    public Object getCredentials() {
        return null;
    }

    @Override
    public Object getDetails() {
        return details;
    }

    @Override
    public Object getPrincipal() {
    return principal;
    }

    @Override
    public boolean isAuthenticated() {
        return isAuth;
    }

    @Override
    public void setAuthenticated(boolean isAuthenticated) throws IllegalArgumentException {
        this.isAuth = isAuthenticated;
    }

    public void setDetails(WebAuthenticationDetails webAuthenticationDetails) {
        this.details = webAuthenticationDetails;
    }
}