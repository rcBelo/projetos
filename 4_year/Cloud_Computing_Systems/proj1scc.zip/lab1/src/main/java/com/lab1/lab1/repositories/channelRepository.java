package com.lab1.lab1.repositories;
import org.springframework.stereotype.Repository;

import com.azure.spring.data.cosmos.repository.CosmosRepository;
import com.lab1.lab1.daos.channelDAO;

@Repository
public interface channelRepository extends CosmosRepository<channelDAO, String> {

  

}