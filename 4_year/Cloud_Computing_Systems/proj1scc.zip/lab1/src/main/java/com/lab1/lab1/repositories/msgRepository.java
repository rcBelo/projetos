package com.lab1.lab1.repositories;
import com.azure.spring.data.cosmos.core.query.CosmosPageRequest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import com.azure.spring.data.cosmos.repository.CosmosRepository;
import com.lab1.lab1.daos.msgDAO;

import java.util.List;

@Repository
public interface msgRepository extends CosmosRepository<msgDAO, String> {

    Page<msgDAO> findAllByChannel(String channel, Pageable page);

    Page<msgDAO> findAll(Pageable page);

    Page<msgDAO> findAllByUser(String user, Pageable page);

    List<msgDAO> findAllByChannel(String channel);

  

}