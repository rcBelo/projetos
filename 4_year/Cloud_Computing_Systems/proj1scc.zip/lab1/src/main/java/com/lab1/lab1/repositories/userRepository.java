package com.lab1.lab1.repositories;

import com.azure.spring.data.cosmos.repository.CosmosRepository;
import com.lab1.lab1.daos.UserDAO;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface userRepository extends CosmosRepository<UserDAO, String> {

    public Optional<UserDAO> findByUsername(String username);

    public Boolean existsByUsername(String username);

  

}