package com.lab1.lab1.services;

import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class ControlService {

    public Optional<String> hello() {
        if (System.currentTimeMillis() > 19)
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Channel does not exist");
        return Optional.of("v: 0001");
    }

}
