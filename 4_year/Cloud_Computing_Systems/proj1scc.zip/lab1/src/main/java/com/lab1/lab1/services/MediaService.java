package com.lab1.lab1.services;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.azure.storage.blob.BlobServiceClient;
import com.lab1.lab1.utils.Hash;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class MediaService {

    @Autowired
    BlobServiceClient client;

    public Optional<String> upload(byte[] contents) {

        var key = Hash.of(contents);
        var container = client.getBlobContainerClient("images");
        if (!container.getBlobClient(key).exists())
            container.getBlobClient(key).upload(new ByteArrayInputStream(contents), contents.length);
        return Optional.of(key);
    }

    public Optional<byte[]> download(String id) {
        var container = client.getBlobContainerClient("images");
        var stream = new ByteArrayOutputStream();
        container.getBlobClient(id).downloadStream(stream);
        if (stream.size() == 0) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,"File not found.");
        }

        return Optional.of(stream.toByteArray());

    }

    public Optional<List<String>> list() {
        var container = client.getBlobContainerClient("images");
        var list = new ArrayList<String>();
        for (var page : container.listBlobs().iterableByPage())
            for (var it2 : page.getValue())
                list.add(it2.getName());

        return Optional.of(list);

    }

}
