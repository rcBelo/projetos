package com.lab1.lab1.services;

import com.azure.core.util.Context;
import com.azure.search.documents.SearchClient;
import com.azure.search.documents.models.SearchOptions;
import com.azure.spring.data.cosmos.core.query.CosmosPageRequest;
import com.lab1.lab1.daos.UserDAO;
import com.lab1.lab1.daos.channelDAO;
import com.lab1.lab1.daos.msgDAO;
import com.lab1.lab1.dtos.UpdateChannelDTO;
import com.lab1.lab1.dtos.channelDTO;
import com.lab1.lab1.dtos.createChannelDTO;
import com.lab1.lab1.dtos.msgDTO;
import com.lab1.lab1.repositories.channelRepository;
import com.lab1.lab1.repositories.msgRepository;
import com.lab1.lab1.repositories.userRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.querydsl.QPageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.Future;
import java.util.stream.Collectors;


@Service
public class channelServices {

    @Autowired
    private channelRepository channels;
    @Autowired
    private userRepository users;
    @Autowired
    private msgRepository msgs;
   @Autowired
   private SearchClient searcher;

    @Transactional
    @CacheEvict(cacheNames = "channels", key = "#id")
    public Optional<Void> deleteChannels(String id) {

        UserDAO userlogged = getUserAuth();
        channelDAO channel = getChannel(id);

        if(!channel.getOwnerId().equals(userlogged.getId())) throw new ResponseStatusException(HttpStatus.FORBIDDEN,"can't delete channel");

        channels.deleteById(id);
        userlogged.getChannelIds().remove(id);
        users.save(userlogged);

        return Optional.empty();
    }

    @Transactional
    @CacheEvict(cacheNames = "users", key = "#auth.principal.id")
    public Optional<channelDTO> createChannels(createChannelDTO newChannel, Authentication auth) {

        UserDAO userlogged = getUserAuth();

        channelDAO channel = new channelDAO(newChannel, userlogged.getId());
        userlogged.getChannelIds().add(channel.getId());
        users.save(userlogged);
        channels.save(channel).getId();
        System.out.println(channel);
        return Optional.of(new channelDTO(channel));
    }

    @Transactional
    @CachePut(cacheNames = "channels", key = "#newChannelInfo.id")
    public Optional<channelDTO> updateChannel(UpdateChannelDTO newChannelInfo) {
        UserDAO userlogged = getUserAuth();
        channelDAO channel = getChannel(newChannelInfo.getId());
        if(!channel.getOwnerId().equals(userlogged.getId())) throw new ResponseStatusException(HttpStatus.FORBIDDEN,"can't update channel");
        channel.update(newChannelInfo);
        channels.save(channel);
        return Optional.of(new channelDTO(channel));
    }

    @Transactional
    @CacheEvict(cacheNames = "users", key = "#userId")
    @CachePut(cacheNames = "channels", key = "#id")
    public Optional<channelDTO> addMember(String id, String userId) {
        channelDAO channel = getChannel(id);

        if (!channel.isPrivateChannel()) throw new ResponseStatusException(HttpStatus.UNAUTHORIZED,"Channel is public");

        UserDAO userlogged = getUserAuth();

        if(!channel.getOwnerId().equals(userlogged.getId())) throw new ResponseStatusException(HttpStatus.FORBIDDEN,"You can not add members to this channel");

        if(channel.getOwnerId().equals(userId)) throw new ResponseStatusException(HttpStatus.FORBIDDEN,"The user is the owner of the channel");

        if(channel.getMembers().contains(userId)) throw new ResponseStatusException(HttpStatus.CONFLICT, "the user is already a member of this channel");

        UserDAO user = getUser(userId);
        channel.getMembers().add(userId);
        channels.save(channel);
        user.getChannelIds().add(id);
        users.save(user);

        return Optional.of(new channelDTO(channel));
    }

    @Transactional
    @CacheEvict(cacheNames = "users", key = "#userId")
    @CachePut(cacheNames = "channels", key = "#id")
    public Optional<channelDTO> removeMember(String id, String userId) {
        channelDAO channel = getChannel(id);

        if (!channel.isPrivateChannel()) throw new ResponseStatusException(HttpStatus.UNAUTHORIZED,"Channel is public");

        UserDAO userlogged = getUserAuth();

        if(!channel.getOwnerId().equals(userlogged.getId())) throw new ResponseStatusException(HttpStatus.FORBIDDEN,"You can not add members to this channel");

        if(channel.getOwnerId().equals(userId)) throw new ResponseStatusException(HttpStatus.FORBIDDEN,"The user is the owner of the channel");

        if(!channel.getMembers().contains(userId)) throw new ResponseStatusException(HttpStatus.NOT_FOUND, "the user is not a member of this channel");

        UserDAO user = getUser(userId);
        channel.getMembers().remove(userId);
        channels.save(channel);
        user.getChannelIds().remove(id);
        users.save(user);

        return Optional.of(new channelDTO(channel));
    }

    @Cacheable(cacheNames = "channels", key = "#id")
    public Optional<channelDTO> getChannelOptional(String id) {

        channelDAO channel = getChannel(id);

        if (!channel.isPrivateChannel()) return Optional.of(new channelDTO(getChannel(id)));

        UserDAO userlogged = getUserAuth();

        if(!channel.getOwnerId().equals(userlogged.getId()) && !userlogged.getChannelIds()
                .contains(channel.getId())) throw new ResponseStatusException(HttpStatus.UNAUTHORIZED,"Cant access the data");

        return Optional.of(new channelDTO(getChannel(id)));
    }

    private UserDAO getUserAuth() {
        return  (UserDAO) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

    }

    private channelDAO getChannel(String id) {
        return channels.findById(id).orElseThrow(()-> new ResponseStatusException(HttpStatus.NOT_FOUND,"Channel not found."));

    }

    private UserDAO getUser(String id) {
        return users.findById(id).orElseThrow(()-> new ResponseStatusException(HttpStatus.NOT_FOUND,"User not found."));

    }

    // todooooooooooooooooooooooooooooooooooooooooooooo palma
    //so quem é membro pode fazer get num canal privado
    @Async
    public Future<Page<msgDTO>> getChannelMessages(int num, int len, String channel) {
        if (!channels.existsById(channel)) throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Channel does not exist");
        var c = getChannel(channel);
        var userlogged = getUserAuth();
        if( c.isPrivateChannel()    &&   !c.getMembers().contains(userlogged.getId())    &&  !c.getOwnerId().equals(userlogged.getId())  ){
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED,"You are not apart of this channel");
            }
        final CosmosPageRequest pageRequest = new CosmosPageRequest(0, len,null);
        Page<msgDAO> page = msgs.findAllByChannel(channel,pageRequest);
        List<msgDAO> content = page.getContent();

        while(page.hasNext()&&page.getNumber()<num){
            Pageable nextPageable = page.nextPageable();
            page=msgs.findAllByChannel(channel,nextPageable);
            content=page.getContent();
        }

        return new AsyncResult<>(new PageImpl<>(content.stream().map(m -> new msgDTO(m)).collect(Collectors.toList())));
    }
    @Async
    public Future<Page<msgDTO>> getChannelMessagesTextSearch(int num, int len, String id,String text){
    if (!channels.existsById(id)) throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Channel does not exist");
    var c = getChannel(id);
    var userlogged = getUserAuth();
    if( c.isPrivateChannel()    &&   !c.getMembers().contains(userlogged.getId())    &&  !c.getOwnerId().equals(userlogged.getId())   )
        throw new ResponseStatusException(HttpStatus.UNAUTHORIZED,"You are not apart of this channel");
    var list = new ArrayList<msgDAO>(len);
    System.out.println(id);
    SearchOptions options = new SearchOptions().setSkip(num*len).setTop(len).setOrderBy("creationDate desc").setFilter(String.format("channel eq '%s'",id));
    searcher.search(text,options, Context.NONE).forEach(r->list.add(r.getDocument(msgDAO.class)));
    return new AsyncResult<>(new PageImpl<>(list.stream().map(m -> new msgDTO(m)).collect(Collectors.toList())));

    }

}
