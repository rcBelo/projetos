package com.lab1.lab1.services;

import java.util.Optional;
import java.util.concurrent.Future;

import com.lab1.lab1.daos.UserDAO;
import com.lab1.lab1.daos.channelDAO;
import com.lab1.lab1.daos.msgDAO;
import com.lab1.lab1.dtos.msgDTO;
import com.lab1.lab1.repositories.channelRepository;
import com.lab1.lab1.repositories.msgRepository;

import com.lab1.lab1.repositories.userRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

@Service
public class msgService {
    @Autowired
    private msgRepository msgs;
    @Autowired
    private channelRepository channels;
    @Autowired
    private userRepository users;

    @Transactional
    public Optional<Void> deleteMessage(String id) {
        msgDAO msg = msgs.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,"Channel does not exist"));
        UserDAO user = getUserAuth();

        if (!user.getId().equals(msg.getUser())) throw new ResponseStatusException(HttpStatus.UNAUTHORIZED,"You are not the owner");
            msg.setReplyTo("DELETED");
        msgs.save(msg);

        return Optional.empty();
    }

    public Optional<msgDTO> getMessage(String id) {
       msgDAO msg = msgs.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,"Channel does not exist"));
       UserDAO user = getUserAuth();
       if (user.getChannelIds().contains(msg.getChannel()))
           return Optional.of(new msgDTO(msg));
       else throw new ResponseStatusException(HttpStatus.FORBIDDEN,"can't acess this content");
    }


    @Transactional
    public Optional<String> addMessage(msgDTO DTO) {
        System.out.println("create msg");
        if (!channels.existsById(DTO.getChannel())) throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Channel not found");
        UserDAO user = getUserAuth();
        channelDAO channel = getChannel(DTO.getChannel());
        if (!user.getChannelIds().contains(DTO.getChannel())) throw new ResponseStatusException(HttpStatus.FORBIDDEN,"can't send a message");

        msgDAO DAO = new msgDAO(DTO, user);
        msgs.save(DAO);
        return Optional.of(DAO.getId());
    }

    private channelDAO getChannel(String id) {
        return channels.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,"Channel not found."));

    }

    private UserDAO getUser(String id) {
        return users.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,"User not found."));

    }

    private UserDAO getUserAuth() {
        return  (UserDAO) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

    }
}
