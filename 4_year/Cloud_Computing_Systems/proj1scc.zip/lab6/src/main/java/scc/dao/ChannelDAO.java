package scc.dao;

import java.util.List;

import lombok.NoArgsConstructor;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ChannelDAO {

    private String id;
    private String name;
    private boolean privateChannel;
    private String ownerId;
    private List<String> members;
}
