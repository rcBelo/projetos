package scc.dao;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class MessageDAO {

    private String id;
    private String replyTo;
    private String channel;
    private String user;
    private String text;
    private String imageId;
    private long creationDate;
}
