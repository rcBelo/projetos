package scc.dao;

import java.util.HashSet;


import lombok.NoArgsConstructor;

import lombok.Data;

@Data
@NoArgsConstructor
public class UserDAO {
    private String id;
    private String name;
    private String pwd;
    private String photoId;
    private HashSet<String> channelIds;
    private String username;
}

