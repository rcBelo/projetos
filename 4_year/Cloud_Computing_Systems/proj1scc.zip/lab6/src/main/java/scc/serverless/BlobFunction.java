package scc.serverless;

import java.io.ByteArrayInputStream;

import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.annotation.BindingName;
import com.microsoft.azure.functions.annotation.BlobTrigger;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.StorageAccount;
import scc.util.utils;

public class BlobFunction {

    @FunctionName("replicate")
    @StorageAccount("AzureWebJobsStorage")
    public void replicate(@BlobTrigger(name = "blob", dataType = "binary", path = "images/{name}") byte[] content,
                          @BindingName("name") String blobname, final ExecutionContext context) {
        context.getLogger().info("BLOB: " + blobname + "; size: " + content.length);
        utils.getClient().getBlobClient(blobname).upload(new ByteArrayInputStream(content), content.length);
        context.getLogger().info("BLOB: " + blobname + " replicated.");
    }
}