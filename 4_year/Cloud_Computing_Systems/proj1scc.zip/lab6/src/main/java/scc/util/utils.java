package scc.util;

import com.azure.cosmos.ConsistencyLevel;
import com.azure.cosmos.CosmosClient;
import com.azure.cosmos.CosmosClientBuilder;
import com.azure.cosmos.CosmosContainer;
import com.azure.cosmos.models.CosmosQueryRequestOptions;
import com.azure.cosmos.models.FeedResponse;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import com.azure.storage.common.StorageSharedKeyCredential;

import java.util.LinkedList;
import java.util.List;

public class utils {
    private static CosmosClient cosmos;
    private static BlobContainerClient blob;

    public static synchronized CosmosClient getCosmosClient() {
        if (cosmos != null)
            return cosmos;
        cosmos = new CosmosClientBuilder().endpoint("https://scc55967.documents.azure.com:443/")
                .key("GnWjpWp6Ic7bihspz3bzNiI1mdoWjAv6as3AScxLfFI7NthMOoGjlMS9vfWxik14YkHn0wkRPGlvvio9zDWiCw==")
                .directMode().consistencyLevel(ConsistencyLevel.SESSION).connectionSharingAcrossClientsEnabled(true)
                .contentResponseOnWriteEnabled(true).buildClient();
        return cosmos;
    }
    public static synchronized BlobContainerClient getClient() {
        if (blob != null)
            return blob;
        blob = new BlobServiceClientBuilder()
                .endpoint(String.format("https://%s.blob.core.windows.net", "scc2022na"))
                .credential(new StorageSharedKeyCredential("scc2022na",
                        "wmHtVRChrf6QYu09Nt8YzLMJTWQpIA5Fp+Vne64elJ0yxEt84FbRHyhW65SEn3MEqgZM2KEyZmOxIjnjJv1/9g=="))
                .buildClient().getBlobContainerClient("imagesna");
        return blob;
    }

    public static <T> List<T> listAll(CosmosContainer container, String query, Class<T> clazz) {
        String token = null;
        var list = new LinkedList<T>();
        do {
            Iterable<FeedResponse<T>> feedResponseIterator = container
                    .queryItems(query, new CosmosQueryRequestOptions(), clazz).iterableByPage(token, 100);
            for (FeedResponse<T> page : feedResponseIterator) {
                list.addAll(page.getResults());
                token = page.getContinuationToken();
            }
        } while (token != null);
        return list;
    }
}
