package com.lab1.lab1;


import com.lab1.lab1.daos.UserDAO;
import com.lab1.lab1.daos.channelDAO;
import com.lab1.lab1.daos.msgDAO;
import com.lab1.lab1.repositories.channelRepository;
import com.lab1.lab1.repositories.msgRepository;
import com.lab1.lab1.repositories.userRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;
import org.springframework.cache.annotation.EnableCaching;

import java.sql.Array;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.UUID;

@SpringBootApplication
@EnableCaching
public class Lab1Application implements CommandLineRunner {

	@Autowired
	private msgRepository msgs;
	@Autowired
	private channelRepository channels;
	@Autowired
	private userRepository users;

	public static void main(String[] args) {
		SpringApplication.run(Lab1Application.class, args);
	}


	@Override
	public void run(String... args) throws Exception {
		/*UserDAO u = new UserDAO(UUID.randomUUID().toString(),"ownerJoao","Joao1","",new HashSet<>(),"ownerjoao");
		UserDAO u2 = new UserDAO(UUID.randomUUID().toString(),"ownerJoao","Joao1","",new HashSet<>(),"ownerjoao");
		var l = new ArrayList<String>();
		l.add(u2.getId());
		channelDAO c = new channelDAO(UUID.randomUUID().toString(), "search", false, u.getId(), l) ;
		msgDAO m1= new msgDAO(UUID.randomUUID().toString(),null,c.getId(),u.getId(),"word olaaaaa",null,System.currentTimeMillis());
		msgDAO m2= new msgDAO(UUID.randomUUID().toString(),null,c.getId(),u2.getId(),"word adeuuuuss",null,System.currentTimeMillis());
		msgDAO m3= new msgDAO(UUID.randomUUID().toString(),null,c.getId(),u2.getId(),"word boooomm dia",null,System.currentTimeMillis());
		msgDAO m4= new msgDAO(UUID.randomUUID().toString(),null,c.getId(),u.getId(),"word mauuuu dia",null,System.currentTimeMillis());

		users.save(u);
		users.save(u2);

		channels.save(c);

		msgs.save(m1);
		msgs.save(m2);
		msgs.save(m3);
		msgs.save(m4);


*/
		//msgs.deleteAll();
		//channels.deleteAll();
		//users.deleteAll();
	}
}
