package com.lab1.lab1.configs;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.azure.core.credential.AzureKeyCredential;
import com.azure.search.documents.SearchClient;
import com.azure.search.documents.SearchClientBuilder;

//@Configuration
//@EnableConfigurationProperties(CognitiveSearchProperties.class)
public class CognitiveSearchConfig {

    //private final CognitiveSearchProperties props;

    /*public CognitiveSearchConfig(CognitiveSearchProperties props) {
        this.props = props;
    }

    @Bean
    public SearchClient client() {
        return new SearchClientBuilder()
                .endpoint(props.getEndpoint())
                .credential(new AzureKeyCredential(props.getKey()))
                .indexName(props.getIndex())
                .buildClient();
    }*/
}