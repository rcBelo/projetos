package com.lab1.lab1.controllers;

import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

public class AbstractController {

    protected static <T> ResponseEntity<T> ok(Optional<T> param) {
        if (!param.isPresent())
            return ResponseEntity.status(HttpStatus.OK).build();
        else
            return ResponseEntity.status(HttpStatus.OK).body(param.get());
    }

    protected static <T> ResponseEntity<T> ok(T param) {
        if (param == null)
            return ResponseEntity.status(HttpStatus.OK).build();
        else
            return ResponseEntity.status(HttpStatus.OK).body(param);
    }
}
