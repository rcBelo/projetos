package com.lab1.lab1.daos;

import java.util.HashSet;
import java.util.UUID;

import com.lab1.lab1.dtos.UpdateUserDTO;
import com.lab1.lab1.dtos.UserDTO;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;

import lombok.Data;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserDAO {
	@Id
	private String id;
	private String name;
	private String pwd;
	private String imageId;
	private HashSet<String> channelIds;
	private String username;


		public UserDAO(UserDTO dto){
			id = UUID.randomUUID().toString();
			this.name=dto.getName();
			this.pwd=dto.getPwd();
			this.imageId=dto.getImageId();
			this.channelIds= new HashSet<>();
			this.username = dto.getUsername();
		}


	public void update(UpdateUserDTO updatedUser, BCryptPasswordEncoder encoder) {
			if(updatedUser.getImageId()!=null)
			this.imageId=updatedUser.getImageId();
			if(updatedUser.getName()!=null)
			this.name=updatedUser.getName();
			if (updatedUser.getPwd()!=null)
				this.pwd = encoder.encode(updatedUser.getPwd());
		
		}

}
