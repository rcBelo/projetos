package com.lab1.lab1.dtos;

import java.io.Serializable;
import java.util.List;

import com.lab1.lab1.daos.channelDAO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;

@AllArgsConstructor
@Data
@NoArgsConstructor
public class UpdateChannelDTO implements Serializable {
    @NotEmpty
    private String id;
    private String name;
}