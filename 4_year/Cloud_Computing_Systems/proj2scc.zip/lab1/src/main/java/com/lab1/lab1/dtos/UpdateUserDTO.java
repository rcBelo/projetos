package com.lab1.lab1.dtos;
import java.io.Serializable;
import java.util.HashSet;

import com.lab1.lab1.daos.UserDAO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UpdateUserDTO implements Serializable {
    private String pwd;
    private String name,imageId;

}