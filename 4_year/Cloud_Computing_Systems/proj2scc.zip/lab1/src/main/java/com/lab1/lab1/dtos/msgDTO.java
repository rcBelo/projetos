package com.lab1.lab1.dtos;

import com.lab1.lab1.daos.msgDAO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class msgDTO implements Serializable {
    private String id;
    private String replyTo;
    @NotEmpty
    private String channel;
    private String user;
    @NotEmpty
    private String text;
    private String imageId;

    public msgDTO(msgDAO DAO){
        this.id = DAO.getId();
        this.replyTo = DAO.getReplyTo();
        this.channel = DAO.getChannel();
        this.user = DAO.getUser();
        this.imageId = DAO.getImageId();
        this.text = DAO.getText();

    }
   
    

}
