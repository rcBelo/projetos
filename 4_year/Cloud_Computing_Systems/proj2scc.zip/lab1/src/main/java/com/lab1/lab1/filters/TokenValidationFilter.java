package com.lab1.lab1.filters;

import com.lab1.lab1.configs.Beans;
import com.lab1.lab1.daos.UserDAO;
import com.lab1.lab1.repositories.userRepository;
import io.jsonwebtoken.Claims;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetails;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.server.ResponseStatusException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;

import java.util.*;

public class TokenValidationFilter extends OncePerRequestFilter {
        private static final String SECRET = "fgjoierdghitreghjmrthijrtyihnryithnjbmrijmobhtjhmbtrrbthjbtrhuintbrhiutbrgiuhnt";
        private userRepository repository;

        public TokenValidationFilter(userRepository repository){
            this.repository=repository;

        }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {

            String token = request.getHeader("Authorization");
            if (token == null)
                throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Token is required");

            token = token.substring(7);
            Claims claims = Jwts.parser().setSigningKey(SECRET).parseClaimsJws(token).getBody();
            UserDAO details = repository.findByUsername((String) claims.get("username")).
                    orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, claims.get("username") + "doesnt exist."));

            TokenAuthentication authenticationToken = new TokenAuthentication(details);

            authenticationToken.setDetails(new WebAuthenticationDetails(request));

            SecurityContextHolder.getContext().setAuthentication(authenticationToken);


            claims.setExpiration(new Date(System.currentTimeMillis() + 600000));
            claims.setIssuedAt(new Date(System.currentTimeMillis()));
            String jwtToken = Jwts.builder().setClaims(claims).setSubject("AuthenticationSCC")
                    .signWith(SignatureAlgorithm.HS512, SECRET).compact();
            response.setHeader("Authorization", "Bearer " + jwtToken);



            filterChain.doFilter(request, response);

    }


        @Override
        protected boolean shouldNotFilter(HttpServletRequest request) throws ServletException{
            HttpMethod method = HttpMethod.resolve(request.getMethod());
            String uri = request.getRequestURI();

          return (uri.contains("/rest/user")&&(method==HttpMethod.POST))
                    ||(uri.contains("/rest/user/login"))
                  || (uri.contains("/rest/media"));

        }
}
