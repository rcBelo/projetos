package com.lab1.lab1.repositories;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.lab1.lab1.daos.channelDAO;

@Repository
public interface channelRepository extends MongoRepository<channelDAO, String> {

  

}