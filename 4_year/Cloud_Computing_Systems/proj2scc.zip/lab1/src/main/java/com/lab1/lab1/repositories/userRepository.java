package com.lab1.lab1.repositories;

import com.lab1.lab1.daos.UserDAO;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface userRepository extends MongoRepository<UserDAO, String> {

    public Optional<UserDAO> findByUsername(String username);

    public Boolean existsByUsername(String username);

  

}