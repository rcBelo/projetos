package com.lab1.lab1.services;

import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

import com.azure.storage.blob.BlobServiceClient;
import com.lab1.lab1.utils.Hash;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class MediaService {

    //@Autowired
    //BlobServiceClient client;

    public Optional<String> upload(byte[] contents) throws IOException {

        var key = Hash.of(contents);

        File outputFile = new File("/mnt/vol/" + key);


        FileUtils.writeByteArrayToFile(outputFile, contents);

        return Optional.of(key);
    }

    public Optional<byte[]> download(String id) throws IOException {

        File outputFile = new File("/mnt/vol/" + id);



        return Optional.of(FileUtils.readFileToByteArray(outputFile));

    }

    public Optional<List<String>> list() {

        System.out.println("before ");
        Iterator<File> files = FileUtils.iterateFiles(new File("/mnt/vol/"), null, null);
        System.out.println("before while");
        List<String> result = new ArrayList<>();
        System.out.println("before while");
        while (files.hasNext()){
            String a = files.next().toString();
            System.out.println(a);
            result.add(a);
        }
        System.out.println("after while");

        return Optional.of(result);

    }

}
