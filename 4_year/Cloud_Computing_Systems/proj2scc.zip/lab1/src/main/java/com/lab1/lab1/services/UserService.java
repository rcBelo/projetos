package com.lab1.lab1.services;

import java.util.Date;
import java.util.HashSet;
import java.util.Optional;
import java.util.concurrent.Future;

import com.lab1.lab1.daos.UserDAO;
import com.lab1.lab1.daos.channelDAO;
import com.lab1.lab1.dtos.UpdateUserDTO;
import com.lab1.lab1.dtos.UserDTO;
import com.lab1.lab1.repositories.channelRepository;
import com.lab1.lab1.repositories.userRepository;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.impl.DefaultClaims;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.web.server.ResponseStatusException;

import javax.servlet.http.HttpServletResponse;

@Service
public class UserService {

    private static final String SECRET = "fgjoierdghitreghjmrthijrtyihnryithnjbmrijmobhtjhmbtrrbthjbtrhuintbrhiutbrgiuhnt";
    @Autowired
    private userRepository users;
    @Autowired
    private channelRepository channels;
    @Autowired
    private BCryptPasswordEncoder encoder;

    @Transactional
    public Optional<UserDAO> register(UserDAO user){
        if (users.existsByUsername(user.getUsername())) throw new ResponseStatusException(HttpStatus.CONFLICT,"Username already taken");
        var pass = user.getPwd();
        if (pass.isEmpty() || pass == null) throw new ResponseStatusException(HttpStatus.NOT_ACCEPTABLE,"Invalid Password");
        user.setPwd(encoder.encode(user.getPwd()));
        users.save(user);
        user.setPwd(pass);// para enviar a password visivel pra o artillery
        return Optional.of(user);
    }
    public Optional<Void> login(String username, String password, HttpServletResponse response){
            UserDAO user = users.findByUsername(username).orElseThrow(()->
                    new ResponseStatusException(HttpStatus.NOT_FOUND,"User " + username + " does not exist"));
            if(!(encoder.matches(password,user.getPwd()))) throw
                    new ResponseStatusException(HttpStatus.NOT_ACCEPTABLE,"Invalid Credentials.");
            Claims claims = new DefaultClaims();
            claims.put("username",user.getUsername());
            claims.setExpiration(new Date(System.currentTimeMillis()+600000)); //10min
            claims.setIssuedAt(new Date(System.currentTimeMillis()));
        String jwtToken = Jwts.builder().setClaims(claims).setSubject("AuthenticationSCC")
                .signWith(SignatureAlgorithm.HS512, SECRET).compact();
        response.addHeader("Authorization", "Bearer " + jwtToken);

        return  Optional.empty();
    }
    public Optional<Void> logout(HttpServletResponse response){
        response.setHeader("Authorization", null);
        return Optional.empty();
    }



    @Transactional
    @CacheEvict(cacheNames = "users", key = "#id")
    public Optional<Void> deleteUser(String id) {
        UserDAO userlogged =(UserDAO) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        userlogged.setPwd("DELETED");
        users.save(userlogged);
        return Optional.empty();
    }


    @Transactional
    @CachePut(cacheNames = "users", key = "#auth.principal.id")
    public Optional<UserDTO> updateUser(UpdateUserDTO updatedUser, Authentication auth) {
        UserDAO userlogged =(UserDAO) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        userlogged.update(updatedUser, encoder);
        users.save(userlogged);
        return Optional.of(new UserDTO(userlogged));
    }

    //ask gonca
    @Transactional
    @CacheEvict(cacheNames = "users", key = "#auth.principal.id")
    public Optional<Void> subscribeChannel(Authentication auth, String channelId) {
        channelDAO channel = getChannel(channelId);

        if (channel.isPrivateChannel()) throw new ResponseStatusException(HttpStatus.UNAUTHORIZED,"Channel is private");

        UserDAO userlogged =(UserDAO) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        if(channel.getOwnerId().equals(userlogged.getId())) throw new ResponseStatusException(HttpStatus.FORBIDDEN,"You are the owner of the channel");

        if(userlogged.getChannelIds().contains(channelId)) throw new ResponseStatusException(HttpStatus.CONFLICT, "the user is already a member of this channel");


        userlogged.getChannelIds().add(channelId);
        users.save(userlogged);
        return Optional.empty();
    }

    @Transactional
    @CacheEvict(cacheNames = "users", key = "#auth.principal.id")
    public Optional<Void> unSubscribeChannel(Authentication auth, String channelId) {

        channelDAO channel = getChannel(channelId);

        if (channel.isPrivateChannel()) throw new ResponseStatusException(HttpStatus.UNAUTHORIZED,"Channel is private");

        UserDAO userlogged =(UserDAO) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        if(channel.getOwnerId().equals(userlogged.getId())) throw new ResponseStatusException(HttpStatus.FORBIDDEN,"You are the owner of the channel");


        if(!userlogged.getChannelIds().contains(channelId)) throw new ResponseStatusException(HttpStatus.CONFLICT, "the user is not a member of this channel");

        userlogged.getChannelIds().remove(channelId);
        users.save(userlogged);
        return Optional.empty();
    }

    private channelDAO getChannel(String id) {
        return channels.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,"Channel not found."));

    }

    public Optional<HashSet<String>> getUserChannels() {
        UserDAO userlogged =(UserDAO) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return Optional.of(userlogged.getChannelIds());
    }

    @Cacheable(cacheNames = "users", key = "#userId")
    public Optional<UserDTO> getUserOptional(String userId) {
        System.out.println("boas");
        var user = getUser(userId);
        System.out.println(user);
        return Optional.of(new UserDTO(user));
    }

    private UserDAO getUser(String id) {
        Authentication auth =SecurityContextHolder.getContext().getAuthentication();
        if(auth!=null && !auth.getPrincipal().equals("anonymousUser") ) {
            UserDAO user =(UserDAO) auth.getPrincipal();
            if(user.getId().equals(id))return user;
        }
        return users.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,"User not found."));

    }

}
