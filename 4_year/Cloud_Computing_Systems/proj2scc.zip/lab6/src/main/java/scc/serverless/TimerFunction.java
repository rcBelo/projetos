package scc.serverless;

import com.azure.cosmos.models.CosmosItemRequestOptions;
import com.microsoft.azure.functions.annotation.*;
import com.microsoft.azure.functions.*;
import scc.dao.ChannelDAO;
import scc.dao.MessageDAO;
import scc.dao.UserDAO;
import scc.util.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Azure Functions with Timer Trigger.
 */
public class TimerFunction {
    @FunctionName("dailyMessages")
    public void cosmosFunction( @TimerTrigger(name = "periodicSetTime", 
    								schedule = "0 0 0 * * *")
    				String timerInfo,
    				ExecutionContext context) {
		var messages = utils.getCosmosClient().getDatabase("scc55967").getContainer("Message");
		var messagesList = utils.listAll(messages, "SELECT * FROM messages", MessageDAO.class);
		Long currentTime = System.currentTimeMillis();
		var nmbMessages = 0;
		for (int i = 0; i < messagesList.size(); i++) {
			var current = messagesList.get(i);
			if(current.getCreationDate() > currentTime - 86400000){
				nmbMessages++;
			}
		}
		context.getLogger().info(String.format("The number of messages in the last day was: %s.", nmbMessages));
	}


	@FunctionName("deleteUser")
	public void deleteUser(@TimerTrigger(name = "periodicSetTime",
			schedule = "0 0 */5 * * *")
													  String timerInfo,
										  ExecutionContext context) {
		var users = utils.getCosmosClient().getDatabase("scc55967").getContainer("User");
		var usersList = utils.listAll(users, "SELECT * FROM users", UserDAO.class);
		var usersDeletedList = utils.listAll(users, "SELECT * FROM users where users.pwd = 'DELETED'", UserDAO.class);

		var messages = utils.getCosmosClient().getDatabase("scc55967").getContainer("Message");
		var messagesList = utils.listAll(messages, "SELECT * FROM messages", MessageDAO.class);


		var channels = utils.getCosmosClient().getDatabase("scc55967").getContainer("Channel");
		var channelsOwnerList =
				utils.listAll(channels, "SELECT * FROM channels", ChannelDAO.class);
		var channelsPrivateList =
				utils.listAll(channels, "SELECT * FROM channels c where c.privateChannel", ChannelDAO.class);


		for (int i = 0; i < messagesList.size(); i++) {
			var currentM = messagesList.get(i);
			for (int j = 0; j < usersDeletedList.size(); j++) {
				if(currentM.getUser().equals(usersDeletedList.get(j).getId()))
				currentM.setUser("Deleted User");
				messages.upsertItem(currentM);
			}
		}

		for (int i = 0; i < channelsOwnerList.size(); i++) {
			var currentC = channelsOwnerList.get(i);
			for (int j = 0; j < usersDeletedList.size(); j++) {
				if(currentC.getOwnerId().equals(usersDeletedList.get(j).getId())){
					channels.deleteItem(currentC, new CosmosItemRequestOptions());
					for (int k = 0; k < usersList.size(); k++) {
						var currentU = usersList.get(k);
						var channelIds = currentU.getChannelIds();
						if(channelIds.contains(currentC.getId())) {
							channelIds.remove(currentC.getId());
							users.upsertItem(currentU);
						}
					}
				}
			}
		}

		for (int i = 0; i < channelsPrivateList.size(); i++) {
			var currentC = channelsPrivateList.get(i);
			List<String> members = currentC.getMembers();
			for (int j = 0; j < usersDeletedList.size(); j++) {
				var currentUserDeleted = usersDeletedList.get(j);
				if(members.contains(currentUserDeleted)) {
					members.remove(currentUserDeleted.getId());
				}
			}
			currentC.setMembers(members);
			channels.upsertItem(currentC);
		}
		for (int i = 0; i < usersDeletedList.size(); i++) {
			users.deleteItem(usersDeletedList.get(i), new CosmosItemRequestOptions());
		}

		context.getLogger().info(String.format("The number of users deleted in the last hour was: %s", usersDeletedList.size()));
	}



	@FunctionName("deleteMessage")
	public void deleteMessage(@TimerTrigger(name = "periodicSetTime",
			schedule = "0 0 */5 * * *")
														 String timerInfo,
											 ExecutionContext context) {

		var Message = utils.getCosmosClient().getDatabase("scc55967").getContainer("Message");
		var messagesDeletedList =
				utils.listAll(Message, "SELECT * FROM Message where Message.replyTo = 'DELETED'", MessageDAO.class);
		var messagesList =
				utils.listAll(Message, "SELECT * FROM Message", MessageDAO.class);


		for (int i = 0; i < messagesList.size(); i++) {
			var currentM = messagesList.get(i);
			for (int j = 0; j < messagesDeletedList.size(); j++) {
				var currentDeleted = messagesDeletedList.get(j);
				if(currentM.getReplyTo() != null && currentM.getReplyTo().equals(currentDeleted.getId())){
					currentM.setReplyTo("Deleted Message");
					Message.upsertItem(currentM);
				}
			}
		}
		for (int i = 0; i < messagesDeletedList.size(); i++) {
			Message.deleteItem(messagesDeletedList.get(i),new CosmosItemRequestOptions());
		}

		context.getLogger().info(String.format("The number of messages deleted in the last hour was: %s", messagesDeletedList.size()));
	}
}

