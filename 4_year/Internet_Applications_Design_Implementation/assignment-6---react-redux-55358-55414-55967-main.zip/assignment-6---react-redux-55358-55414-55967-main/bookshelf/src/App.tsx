import React from 'react';
import logo from './logo.svg';
import './App.css';
import { Route, Routes } from 'react-router-dom';
import NavBar from './Components/NavBar/NavBar';
import SignIn from './Components/SignIn/SignIn';
import BookList from './Components/BookLists/BookList';
import Book from './Components/BookLists/Book';

function App() {
  return (
    <>
    <NavBar/>
    <Routes>
      <Route path="/" element={<BookList />}/>
      <Route path="/signin" element={<SignIn/>}/>
      <Route path="/book/:id" element={<Book/>}/>
    </Routes>
    </>
  );
}

export default App;
