import classes from './BookList.module.css'
import { TextField, Button } from '@mui/material';
import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getOneBook, updateOne } from '../../services/httpRequest';


interface Author {
    name: string
}
interface Image {
    url: string
}
interface ImageUp {
    url: string;
    delete: boolean;
}

interface Input {
    newImage: string;
    newAuthor: number;
    newTitle: string;
}
interface BookInterface {
    title: string;
    author: number[];
    image: string[];
    images: Image[];
}

function Book() {
    const [book, setBook] = useState<BookInterface>({
        title: "",
        author: [],
        images: [],
        image: []
    }
    );
    const [input, setInput] = useState<Input>({
        newImage: "",
        newAuthor: -1,
        newTitle: ""
    });
    const url = useParams();
    const navigate = useNavigate()
    const startImage = "";

    useEffect(() => {
        if (url.id) {
            getOneBook(url.id).then(
                (response: any) => {
                    let newBook: BookInterface = response.data

                    setBook(prev => {
                        newBook.image = []
                        for (let elem of newBook.images) {
                            newBook.image.push(elem.url)
                        }

                        return newBook
                    })

                    setInput({ ...input, newTitle: response.data.title })
                },
                (error: any) => {
                    console.log(error)
                }
            );
        }
    }, [])

    /*useEffect(()=>{
        if(book)
        for(let i = 0; i < book.images.length; i++){
            book.image.push(book.images[i].url);
        }
    },[book])*/

    useEffect(() => {

    }, [])

    const changeImage = (e: any) => {
        setInput({ ...input, newImage: e.target.value });
    }

    const changeTitle = (e: any) => {
        setInput({ ...input, newTitle: e.target.value });
    }

    const changeAuthor = (e: any) => {
        setInput({ ...input, newAuthor: parseInt(e.target.value) });
    }

    const confirmEdit = () => {
        if (url.id && book) {



            console.log(book)
            updateOne(url.id, book.title, book.author, book.image).then(
                (response: any) => {
                    navigate("/")
                },
                (error: any) => {
                    console.log(error)
                }
            );
        }
    }

    const deleteImage = (index: number) => {
        book?.images.splice(index, 1)
    }

    const addAuthor = () => {
        if (book)
            setBook(prev => {
                let book = { ...prev }
                book.author = [];
                book.author.push(input.newAuthor)
                setInput({ ...input, newAuthor: -1 });
                return book
            })
    }

    const addTitle = () => {
        if (book)
            setBook(prev => {return {...prev, title: input.newTitle}})
}

const addImage = () => {
    if (book)
        setBook(prev => {
            let book = { ...prev }
            book.image.push(input.newImage)
            setInput({ ...input, newImage: "" });
            return book
        })
}
return (


    <div className={classes.wrapper}>


        <TextField className={classes.textField} label="Title" value={input.newTitle} onChange={changeTitle} multiline></TextField>
        <Button className={classes.button} onClick={addTitle}>Update Title</Button>
        {book && book.images.map((image, index) => (
            <img onClick={() => deleteImage(index)} src={image.url}>
            </img> 

        ))
        }


        <TextField className={classes.textField} label="New Image" value={input.newImage} onChange={changeImage} multiline></TextField>
        <Button className={classes.button} onClick={addImage}>Add Image</Button>
        <TextField id="standard-number" label="Author" type="number" className={classes.textField}
            onChange={changeAuthor} multiline></TextField>
        <Button className={classes.button} onClick={addAuthor}>Add Author</Button>
        <Button className={classes.button} onClick={confirmEdit}>Save & Submit</Button>
    </div>
)
}

export default Book