import { useState, useEffect, ChangeEvent } from 'react';
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import classes from './BookList.module.css'
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { useLocation, useNavigate } from 'react-router-dom';
import { Modal, TextField } from '@mui/material';
import Rating from '@mui/material/Rating';
import { useSelector } from 'react-redux';
import { root } from "../../store/store";
import { getAllBooks, addOneBook } from '../../services/httpRequest';


const theme = createTheme();
interface Author {
  name:string
}
interface Image {
  url:string
}
export interface BookInterface {
  id:string;
  title: string;
  authors: Author[];
  images: Image[];
}

interface BookCreate{
  title:string;
  authors: number;
  images: string;
  titleIsValid:boolean;
  authorsIsValid:boolean;
  imagesIsValid:boolean;
}
const style = {
  position: 'absolute' as 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 400,
  overflow:'scroll',
  bgcolor: 'background.paper',
  border: '2px solid #000',
  boxShadow: 24,
  p: 4,
};
export default function BookList() {

  const location = useLocation()
  const store = useSelector(root)
  
  const userType = location.pathname.replace("/", "")
  const [books, setBooks] = useState<BookInterface[]>([])
  const [input, setInput] = useState<BookCreate>({
    title:"",
    authors:0,
    images:"",
    titleIsValid:false,
    authorsIsValid:false,
    imagesIsValid:false
  })
  useEffect(() => {
    getAllBooks().then(
      (response: any) => {
        console.log(response.data)
        setBooks(response.data)
      },
      (error: any) => {
        console.log(error)
       }
    );
  }, [])
  const [rating, setRating] = useState<number>(0);
  const [name, setName] = useState<string>("");
  const handleRatingChange = (event: any) => {
    setRating(parseInt(event.target.value));
  };
  const handleNameChange = (event: any) => {
    setName(event.target.value);
  };
 
  const [open, setOpen] = useState<{ openModal: boolean }>();
  const showModal = () => {
    setOpen({ openModal: true})
  }

  const navigate = useNavigate();
  const changeTitle = (e:any) =>{
    if(e.target.value.length > 0)
    setInput({... input, titleIsValid:true, title:e.target.value})
    else
    setInput({... input, titleIsValid:false, title:e.target.value})
  }
  const changeImage = (e:any) =>{
    if(e.target.value.length > 0)
    setInput({... input, imagesIsValid:true, images:e.target.value})
    else
    setInput({... input, imagesIsValid:false, images:e.target.value})
  }
  const changeAuthor = (e:any) =>{
    if(e.target.value.length > 0)
    setInput({... input, authorsIsValid:true, authors:parseInt(e.target.value)})
    else
    setInput({... input, authorsIsValid:false, authors:parseInt(e.target.value)})
  }
  const closeModal = () => {
    setOpen({ openModal: false })
  }
  useEffect(()=>{
console.log(input.authors)
  }, [input.authors])
  const [formValid, setFormValid] = useState<boolean>(false)
  
  useEffect(()=>{
    if(input.titleIsValid && input.imagesIsValid && input.authorsIsValid)
    setFormValid(true)
    else
    setFormValid(false)
  }, [input.titleIsValid, input.imagesIsValid, input.authorsIsValid])

  const addBook = () => {
    addOneBook(input.title, [input.authors],[input.images] ).then(
      (response: any) => {
        console.log(response.data)
        setBooks(books=> [... books, response.data])
        closeModal();
      },
      (error: any) => {
        console.log(error)
       }
    );
    
  }
  const [imageToShow, setImageToShow] = useState<number>(0)
  useEffect(() => {
    setInterval(() => {
      setImageToShow(prev => prev + 1)
    }, 10000);
  },[])

 

  return (
    <ThemeProvider theme={theme}>
      <main>
        {!store.roles.includes("ANONYMOUS") &&
          <div>
            <p>
              Name:
              <input onChange={handleNameChange} type="search"></input>
            </p>
            <p>Rating:
              <select style={{ borderRadius: "7px", width: "auto", marginLeft: "10px", fontSize: "20px" }} onChange={handleRatingChange}>
                <option selected value={0}>Show All</option>
                <option value={1}>1</option>
                <option value={2}>2</option>
                <option value={3}>3</option>
                <option value={4}>4</option>
                <option value={5}>5</option>
              </select>
            </p>
          </div>
        }
        {store.roles.includes("ROLE_USER") && <Button onClick={showModal}>
        Add Book
        </Button>}
        <Container sx={{ py: 8 }} maxWidth="md">
          <Grid container spacing={4}>
            {books.map((book, index) => (
               book.title.toLowerCase().includes(name.toLowerCase()) &&
                <Grid item key={index} xs={12} sm={6} md={4}>
                  <Card
                    sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}
                  >
                    <CardMedia
                      sx={{ height: '30em', width: '100%' }}
                      component="img"
                      image={book.images[Math.round(imageToShow%book.images.length)].url}
                    />
                    <CardContent sx={{ flexGrow: 1 }}>
                      <Typography gutterBottom variant="h5" component="h2">
                        {book.title}
                      </Typography>
                      <div>
                       {book.authors.map((author, index) => (
                         <p>
                          {author.name}
                         </p>
                        ))
                       } 
                      </div>
                    </CardContent>
                    {store.roles.includes("ROLE_REVIEWER") &&
                    <Button onClick={() => navigate("/book/" + book.id)} size="small">Edit</Button>
                      }
                  </Card>
                </Grid>
            ))}
          </Grid>
        </Container>
        <Modal open={open?.openModal || false} onClose={closeModal}>
          <Box  sx={style}>
            {open &&
              <>
                {<div className = {classes.wrapper}>
                  <TextField className = {classes.textField} label= "Title"onChange={changeTitle} multiline></TextField>
                  <TextField id="standard-number" label="Author" type="number" className = {classes.textField} onChange={changeAuthor} ></TextField>
                  <TextField className = {classes.textField} label = "Image"onChange={changeImage} multiline></TextField>
                  <Button className={classes.button} disabled={!formValid} onClick={addBook}>Confirm</Button>
                </div>}
              </>
            }
          </Box>
        </Modal>
      </main>
    </ThemeProvider>
  );
}

/*
<img style={{width:'390px', height:'550px'}} src={books[open.index].images[imageIndex]}/>
                        <FiChevronLeft />
                        <FiChevronRight/>
*/
