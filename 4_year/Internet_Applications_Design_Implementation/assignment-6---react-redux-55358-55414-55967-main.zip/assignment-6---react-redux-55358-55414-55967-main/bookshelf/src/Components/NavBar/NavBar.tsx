

import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import { Link, useNavigate } from 'react-router-dom';
export default function NavBar(){
    const navigate = useNavigate();
  const redirectSignin = () =>{
    navigate("/signin")
  }
    return(
        <AppBar
        position="static"
        color="default"
        elevation={0}
        sx={{ borderBottom: (theme) => `1px solid ${theme.palette.divider}` }}
      >
        <Toolbar sx={{ flexWrap: 'wrap' }}>
            <Link to = "/">
          <Typography variant="h6" color="inherit" noWrap sx={{ flexGrow: 1 }}>
            BookStore
          </Typography>
            </Link>
          <Button onClick={redirectSignin} variant="outlined" sx={{ my: 1, mx: 1.5 }}>
            Sign In
          </Button>
        </Toolbar>
      </AppBar>
    )
}