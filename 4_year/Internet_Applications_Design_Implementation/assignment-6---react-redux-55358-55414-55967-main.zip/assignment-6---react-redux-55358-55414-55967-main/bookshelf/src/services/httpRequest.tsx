import axios, { AxiosRequestConfig, AxiosResponse } from "axios";
import { useDispatch } from "react-redux";
import { logout, resetToken } from "../store/slices";
import {store} from "../store/store";
const url = "http://localhost:8080";

axios.interceptors.request.use(
  function (c: AxiosRequestConfig) {
    console.log(store.getState().token)
    let token = store.getState().token;
    if (token && c.headers) {
      c.headers["Authorization"] = token;
    }
    return c;
  },
  function (error: any) {
    return Promise.reject(error);
  }
);

axios.interceptors.response.use(
  function (response: AxiosResponse) {
    if (
      response.headers &&
      response.headers["Authorization"] &&
      store.getState().token !== ""
    ) {
      store.dispatch(resetToken(response.headers["Authorization"]));
      localStorage.setItem("token", response.headers["Authorization"]);
    }
    return response;
  },

  function (error: any) {
    if (error.response.status === 401) {
      alert("A sua sessão expirou, por favor efectue novo login");
      store.dispatch(logout());
      localStorage.removeItem("token");
    }
    return Promise.reject(error);
  }
);
  export async function loginRequest(email: string, password: string) {
    try {
      return await axios.put(`${url}/login`, {
        username: email,
        password: password,
      });
    } catch (error:any) {
      throw error.response;
    }
  }
  export async function logoutRequest() {
    try {
      return await axios.put(`${url}/logout`);
    } catch (error:any) {
      throw error.response;
    }
  }

  export async function getAllBooks() {
    try {
      return await axios.get(`${url}/user/books`);
    } catch (error:any) {
      throw error.response;
    }
  }
  export async function getOneBook(id:string) {
    try {
      return await axios.get(`${url}/user/books/${id}`);
    } catch (error:any) {
      throw error.response;
    }
    
  }

  export async function addOneBook(title:string, authors:number[],images:string[]) {
    console.log(authors)
    try {
      return await axios.post(`${url}/user/books`,{
          title:title,
          authors:authors,
          images:images
      });
    } catch (error:any) {
      throw error.response;
    }
  }
  export async function updateOne(id:string, title:string, authors:number[],images:string[]) {
    try {
      return await axios.put(`${url}/user/books/${id}`,{
          title:title,
          authors:authors,
          images:images
      });
    } catch (error:any) {
      throw error.response;
    }
  }
  export async function deleteBook(id:string) {
    try {
      return await axios.delete(`${url}/user/books/${id}`);
    } catch (error:any) {
      throw error.response;
    }
  }
  export async function getAllAuthors() {
    try {
      return await axios.get(`${url}/authors`);
    } catch (error:any) {
      throw error.response;
    }
  }
  export async function addOneAuthor(name:string) {
    try {
      return await axios.post(`${url}/authors`, {
          name:name
      });
    } catch (error:any) {
      throw error.response;
    }
  }
  export async function getOneAuthor(id:string) {
    try {
      return await axios.get(`${url}/authors/${id}`);
    } catch (error:any) {
      throw error.response;
    }
  }

  export async function updateOneAuthor(id:string, name:string) {
    try {
      return await axios.put(`${url}/authors/${id}`,{
          name:name
      });
    } catch (error:any) {
      throw error.response;
    }
  }
  export async function deleteAuthor(id:string) {
    try {
      return await axios.delete(`${url}/authors/${id}`);
    } catch (error:any) {
      throw error.response;
    }
  }
