import { Session } from "./types";
import {createSlice, PayloadAction} from "@reduxjs/toolkit"

const initialSession: Session = {
    isLogged: false,
    token: "",
    username: "",
    roles: []
}
const sessionSlice = createSlice({
    name: "Session",
    initialState: initialSession,
    reducers:{
        login:(state:Session, action:PayloadAction<Session>) => { 
            return action.payload
        },
        logout:() => initialSession,
        resetToken:(state:Session, action:PayloadAction<string>) => {
            state.token = action.payload
            return state
        }
    }
});

export {sessionSlice}
export const {login,logout,resetToken} = sessionSlice.actions