import { configureStore, createSelector } from "@reduxjs/toolkit";
import { sessionSlice } from "./slices";
import { Session } from "./types";

const store = configureStore({
    reducer: sessionSlice.reducer
    
})
//ISTO É PARA LER BOYS SÓ LER LEEEEEEEEEEEEEERRRRRRRRRRRRRRRRRR TIPO USESTATES
const root = createSelector((state:RootReducer) => state, (state:RootReducer) => state)

type RootReducer = ReturnType<typeof store.getState> 
export {store, root}