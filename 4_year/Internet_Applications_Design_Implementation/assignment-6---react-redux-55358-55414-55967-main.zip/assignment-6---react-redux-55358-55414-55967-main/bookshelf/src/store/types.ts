export interface Session {
    isLogged:boolean
    token:string
    username:string
    roles:string[]
}