package pt.unl.fct.di.iadidemo.bookshelf.application.services.exceptions

class NoAuthorException(message:String): Exception(message)