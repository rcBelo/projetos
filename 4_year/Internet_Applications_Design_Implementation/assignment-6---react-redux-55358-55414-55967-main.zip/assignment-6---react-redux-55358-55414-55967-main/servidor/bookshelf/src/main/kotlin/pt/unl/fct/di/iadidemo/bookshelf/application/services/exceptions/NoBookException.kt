package pt.unl.fct.di.iadidemo.bookshelf.application.services.exceptions

class NoBookException(message:String): Exception(message)