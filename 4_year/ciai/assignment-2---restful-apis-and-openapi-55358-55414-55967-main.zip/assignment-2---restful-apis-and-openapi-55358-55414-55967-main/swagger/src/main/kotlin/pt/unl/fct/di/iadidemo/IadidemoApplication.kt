package pt.unl.fct.di.iadidemo

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class IadidemoApplication

fun main(args: Array<String>) {
    runApplication<IadidemoApplication>(*args)
}
