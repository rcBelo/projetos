package pt.unl.fct.di.iadidemo.presentation.api


import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.Parameter
import io.swagger.v3.oas.annotations.responses.ApiResponse
import io.swagger.v3.oas.annotations.responses.ApiResponses
import io.swagger.v3.oas.annotations.tags.Tag
import org.springframework.data.domain.Page
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import pt.unl.fct.di.iadidemo.presentation.dto.AuthorDto
@Tag(name = "Author API",
    description = "This are the methods available for the Author Entity")

@RequestMapping("/author")
interface AuthorInterface {

    @Operation(summary = "Create an author")
    @ApiResponses(
        value = [
            ApiResponse(responseCode = "200", description = "Successfully created author"),
            ApiResponse(responseCode = "400", description = "Bad request"),
            ApiResponse(responseCode = "500", description = "Internal server error")
        ]
    )
    @PostMapping
    fun createAuthor(@Parameter(name = "AuthorDto", required = true) @RequestBody dto: AuthorDto): ResponseEntity<AuthorDto>

    @Operation(summary = "Get an author")
    @ApiResponses(
        value = [
            ApiResponse(responseCode = "200", description = "Successfully retrieved author"),
            ApiResponse(responseCode = "400", description = "Bad request"),
            ApiResponse(responseCode = "404", description = "not found"),
            ApiResponse(responseCode = "500", description = "Internal server error")
        ]
    )
    @GetMapping("/{authorId}")
    fun getAuthor(@Parameter(name = "AuthorId", required = true) @PathVariable authorId: String): ResponseEntity<AuthorDto>

    @Operation(summary = "Delete an author")
    @ApiResponses(
        value = [
            ApiResponse(responseCode = "200", description = "Successfully deleted author"),
            ApiResponse(responseCode = "400", description = "Bad request"),
            ApiResponse(responseCode = "404", description = "Not found"),
            ApiResponse(responseCode = "500", description = "Internal server error")
        ]
    )
    @DeleteMapping("/{authorId}")
    fun deleteAuthor(@Parameter(name = "AuthorId", required = true) @PathVariable authorId: String): ResponseEntity<AuthorDto>


    @Operation(summary = "Returns the authors that fit the input as a Page")
    @ApiResponses(
        value = [
            ApiResponse(responseCode = "200", description = "Successfully returned authors"),
            ApiResponse(responseCode = "400", description = "Bad request"),
            ApiResponse(responseCode = "404", description = "Not found"),
            ApiResponse(responseCode = "500", description = "Internal server error")
        ]
    )
    @GetMapping
    fun find(
        @Parameter(name = "Page number", required = false) @RequestParam(defaultValue = "0") number: Int,
        @Parameter(name = "Size of the requested page", required = false) @RequestParam(defaultValue = "10") size: Int,
        @Parameter(name = "order of the page", required = false) @RequestParam(defaultValue = "") order: String,
        @Parameter(name = "Direction of the values presented", required = false) @RequestParam(defaultValue = "ASC") dir: String
    ): ResponseEntity<Page<AuthorDto>>

    @Operation(summary = "Get books from an author")
    @ApiResponses(
        value = [
            ApiResponse(responseCode = "200", description = "Successfully returned books"),
            ApiResponse(responseCode = "400", description = "Bad request"),
            ApiResponse(responseCode = "404", description = "Not found"),
            ApiResponse(responseCode = "500", description = "Internal server error")
        ]
    )
    @GetMapping("/author")
    fun getAuthorBooks(@Parameter(name = "AuthorId", required = true) @RequestParam() authorId: String, @Parameter(name = "Page number", required = false) @RequestParam(defaultValue = "0") number: Int,
                       @Parameter(name = "Size of the requested page", required = false) @RequestParam(defaultValue = "10") size: Int,
                       @Parameter(name = "order of the page", required = false) @RequestParam(defaultValue = "") order: String,
                       @Parameter(name = "Direction of the values presented", required = false) @RequestParam(defaultValue = "ASC") dir: String):ResponseEntity<Page<String>>


    @Operation(summary = "Add a book to an author")
    @ApiResponses(
        value = [
            ApiResponse(responseCode = "200", description = "Successfully added books"),
            ApiResponse(responseCode = "400", description = "Bad request"),
            ApiResponse(responseCode = "404", description = "Not found"),
            ApiResponse(responseCode = "500", description = "Internal server error")
        ]
    )
    @PutMapping("/{authorId}/{bookId}")
    fun addAuthorBook(@Parameter(name = "AuthorId", required = true) @PathVariable authorId: String,@Parameter(name = "BookId", required = true)@PathVariable bookId: String):ResponseEntity<String>

    @Operation(summary = "Remove a book from an author")
    @ApiResponses(
        value = [
            ApiResponse(responseCode = "200", description = "Successfully removed books"),
            ApiResponse(responseCode = "400", description = "Bad request"),
            ApiResponse(responseCode = "404", description = "Not found"),
            ApiResponse(responseCode = "500", description = "Internal server error")
        ]
    )
    @DeleteMapping("/{authorId}/{bookId}")
    fun removeAuthorBook(@Parameter(name = "AuthorId", required = true) @PathVariable authorId: String,@Parameter(name = "BookId", required = true) @PathVariable bookId: String):ResponseEntity<String>

}
