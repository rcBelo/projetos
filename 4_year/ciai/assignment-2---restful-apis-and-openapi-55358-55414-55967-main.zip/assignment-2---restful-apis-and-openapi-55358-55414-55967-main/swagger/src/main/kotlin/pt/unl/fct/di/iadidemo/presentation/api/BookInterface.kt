package pt.unl.fct.di.iadidemo.presentation.api

import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.Parameter
import io.swagger.v3.oas.annotations.responses.ApiResponse
import io.swagger.v3.oas.annotations.responses.ApiResponses
import io.swagger.v3.oas.annotations.tags.Tag
import org.springframework.data.domain.Page
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import pt.unl.fct.di.iadidemo.presentation.dto.BookDto
import pt.unl.fct.di.iadidemo.presentation.dto.RateDto
import pt.unl.fct.di.iadidemo.presentation.dto.reviewDto

@Tag(name = "Book API",
    description = "This are the methods available for the Book Entity")
@RequestMapping("/book")
interface BookInterface {

    @Operation(summary = "Create a book")
    @ApiResponses(
        value = [
            ApiResponse(responseCode = "200", description = "Successfully created book"),
            ApiResponse(responseCode = "400", description = "Bad request"),
            ApiResponse(responseCode = "500", description = "Internal server error")
        ]
    )
    @PostMapping
    fun createBook(@Parameter(name = "BookDto", required = true) @RequestBody bookdto: BookDto): ResponseEntity<BookDto>

    @Operation(summary = "Get a book")
    @ApiResponses(
        value = [
            ApiResponse(responseCode = "200", description = "Successfully retrieved book"),
            ApiResponse(responseCode = "400", description = "Bad request"),
            ApiResponse(responseCode = "404", description = "Not found"),
            ApiResponse(responseCode = "500", description = "Internal server error")
        ]
    )
    @GetMapping("/{bookId}")
    fun getBook(@Parameter(name = "BookId", required = true) @PathVariable bookId: String): ResponseEntity<BookDto>

    @Operation(summary = "Delete a book")
    @ApiResponses(
        value = [
            ApiResponse(responseCode = "200", description = "Successfully deleted book"),
            ApiResponse(responseCode = "400", description = "Bad request"),
            ApiResponse(responseCode = "404", description = "Not found"),
            ApiResponse(responseCode = "500", description = "Internal server error")
        ]
    )
    @DeleteMapping("/{bookId}")
    fun deleteBook(@Parameter(name = "BookId", required = true) @PathVariable bookId: String): ResponseEntity<BookDto>


    @Operation(summary = "Returns the book that fit the input as a Page")
    @ApiResponses(
        value = [
            ApiResponse(responseCode = "200", description = "Successfully returned books"),
            ApiResponse(responseCode = "400", description = "Bad request"),
            ApiResponse(responseCode = "404", description = "Not found"),
            ApiResponse(responseCode = "500", description = "Internal server error")
        ]
    )
    @GetMapping
    fun find(
        @Parameter(name = "Page number", required = false) @RequestParam(defaultValue = "0") number: Int,
        @Parameter(name = "Size of the requested page", required = false) @RequestParam(defaultValue = "10") size: Int,
        @Parameter(name = "order of the page", required = false) @RequestParam(defaultValue = "") order: String,
        @Parameter(name = "Direction of the values presented", required = false) @RequestParam(defaultValue = "ASC") dir: String
    ): ResponseEntity<Page<BookDto>>

    @Operation(summary = "Rate a book")
    @ApiResponses(
        value = [
            ApiResponse(responseCode = "200", description = "Successfully rated book"),
            ApiResponse(responseCode = "400", description = "Bad request"),
            ApiResponse(responseCode = "404", description = "Not found"),
            ApiResponse(responseCode = "500", description = "Internal server error")
        ]
    )
    @PutMapping("/rate")
    fun rateBook(@Parameter(name = "RateDto", required = true)@RequestBody rate:RateDto): ResponseEntity<RateDto>

    @Operation(summary = "Review a book")
    @ApiResponses(
        value = [
            ApiResponse(responseCode = "200", description = "Successfully reviewed book"),
            ApiResponse(responseCode = "400", description = "Bad request"),
            ApiResponse(responseCode = "404", description = "not found"),
            ApiResponse(responseCode = "500", description = "Internal server error")
        ]
    )
    @PutMapping
    fun reviewBook(@Parameter(name = "reviewDto", required = true)@RequestBody review:reviewDto): ResponseEntity<reviewDto>

}
