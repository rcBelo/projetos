package pt.unl.fct.di.iadidemo.presentation.api


import io.swagger.v3.oas.annotations.Operation
import io.swagger.v3.oas.annotations.Parameter
import io.swagger.v3.oas.annotations.responses.ApiResponse
import io.swagger.v3.oas.annotations.responses.ApiResponses
import io.swagger.v3.oas.annotations.tags.Tag
import org.springframework.data.domain.Page
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.*
import pt.unl.fct.di.iadidemo.presentation.dto.UserDto

@Tag(name = "User API",
    description = "This are the methods available for the User Entity")
@RequestMapping("/user")
interface UserInterface {

    @Operation(summary = "Create a user")
    @ApiResponses(
        value = [
            ApiResponse(responseCode = "200", description = "Successfully created user"),
            ApiResponse(responseCode = "400", description = "Bad request"),
            ApiResponse(responseCode = "500", description = "Internal server error")
        ]
    )
    @PostMapping
    fun createUser(@Parameter(name = "UserDto", required = true) @RequestBody dto: UserDto): ResponseEntity<UserDto>

    @Operation(summary = "Get a user")
    @ApiResponses(
        value = [
            ApiResponse(responseCode = "200", description = "Successfully retrieved user"),
            ApiResponse(responseCode = "400", description = "Bad request"),
            ApiResponse(responseCode = "404", description = "Not found"),
            ApiResponse(responseCode = "500", description = "Internal server error")
        ]
    )
    @GetMapping("/{userId}")
    fun getUser(@Parameter(name = "UserId", required = true) @PathVariable userId: String): ResponseEntity<UserDto>

    @Operation(summary = "Delete a user")
    @ApiResponses(
        value = [
            ApiResponse(responseCode = "200", description = "Successfully deleted user"),
            ApiResponse(responseCode = "400", description = "Bad request"),
            ApiResponse(responseCode = "404", description = "Not found"),
            ApiResponse(responseCode = "500", description = "Internal server error")
        ]
    )
    @DeleteMapping("/{userId}")
    fun deleteUser(@Parameter(name = "UserId", required = true) @PathVariable userId: String): ResponseEntity<UserDto>


    @Operation(summary = "Returns the users that fit the input as a Page")
    @ApiResponses(
        value = [
            ApiResponse(responseCode = "200", description = "Successfully returned users"),
            ApiResponse(responseCode = "400", description = "Bad request"),
            ApiResponse(responseCode = "404", description = "Not found"),
            ApiResponse(responseCode = "500", description = "Internal server error")
        ]
    )
    @GetMapping
    fun find(
        @Parameter(name = "Page number", required = false) @RequestParam(defaultValue = "0") number: Int,
        @Parameter(name = "Size of the requested page", required = false) @RequestParam(defaultValue = "10") size: Int,
        @Parameter(name = "order of the page", required = false) @RequestParam(defaultValue = "") order: String,
        @Parameter(name = "Direction of the values presented", required = false) @RequestParam(defaultValue = "ASC") dir: String
    ): ResponseEntity<Page<UserDto>>

    @Operation(summary = "Get favorite books from a user")
    @ApiResponses(
        value = [
            ApiResponse(responseCode = "200", description = "Successfully retrieved books"),
            ApiResponse(responseCode = "400", description = "Bad request"),
            ApiResponse(responseCode = "404", description = "not found"),
            ApiResponse(responseCode = "500", description = "Internal server error")
        ]
    )
    @GetMapping("/{userId}/books")
    fun getFavBooks(@Parameter(name = "User id", required = true) @PathVariable userId: String,
                    @Parameter(name = "Page number", required = false) @RequestParam(defaultValue = "0") number: Int,
                    @Parameter(name = "Size of the requested page", required = false) @RequestParam(defaultValue = "10") size: Int,
                    @Parameter(name = "order of the page", required = false) @RequestParam(defaultValue = "") order: String,
                    @Parameter(name = "Direction of the values presented", required = false) @RequestParam(defaultValue = "ASC") dir: String)
            :ResponseEntity<Page<String>>

    @Operation(summary = "Add a favorite book to a user")
    @ApiResponses(
        value = [
            ApiResponse(responseCode = "200", description = "Successfully added book"),
            ApiResponse(responseCode = "400", description = "Bad request"),
            ApiResponse(responseCode = "404", description = "Not found"),
            ApiResponse(responseCode = "500", description = "Internal server error")
        ]
    )
    @PutMapping
    fun addFavBook(@Parameter(name = "userId", required = true) @RequestBody userId:String,@Parameter(name = "Book name", required = true) @RequestBody book:String):ResponseEntity<String>

    @Operation(summary = "Delete a favorite book from a user")
    @ApiResponses(
        value = [
            ApiResponse(responseCode = "200", description = "Successfully deleted book"),
            ApiResponse(responseCode = "400", description = "Bad request"),
            ApiResponse(responseCode = "404", description = "nNot found"),
            ApiResponse(responseCode = "500", description = "Internal server error")
        ]
    )
    @DeleteMapping("/{userId}/{book}")
    fun removeFavBook(@Parameter(name = "userId", required = true) @PathVariable userId:String,@Parameter(name = "Book name", required = true) @PathVariable book:String):ResponseEntity<String>
}
