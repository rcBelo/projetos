package pt.unl.fct.di.iadidemo.presentation.controller

import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import java.util.*

abstract class AbstractController {
    fun <T> ok(param: Optional<T>):ResponseEntity<T>{
        return if (!param.isPresent)
            ResponseEntity.status(HttpStatus.OK).build()
        else
            ResponseEntity.status(HttpStatus.OK).body(param.get())
    }

    fun <T> ok(param:T):ResponseEntity<T>{
        return if (param == null)
            ResponseEntity.status(HttpStatus.OK).build()
        else
            ResponseEntity.status(HttpStatus.OK).body(param)

    }

}