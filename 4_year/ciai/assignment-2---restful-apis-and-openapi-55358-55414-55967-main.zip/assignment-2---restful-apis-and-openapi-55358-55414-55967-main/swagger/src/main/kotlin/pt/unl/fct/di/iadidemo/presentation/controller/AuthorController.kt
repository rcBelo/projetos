package pt.unl.fct.di.iadidemo.presentation.controller

import org.springframework.data.domain.Page
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.RestController
import pt.unl.fct.di.iadidemo.presentation.api.AuthorInterface
import pt.unl.fct.di.iadidemo.presentation.dto.AuthorDto
import pt.unl.fct.di.iadidemo.presentation.service.AuthorService
@RestController
class AuthorController(val service: AuthorService) : AuthorInterface, AbstractController() {
    override fun createAuthor(dto: AuthorDto): ResponseEntity<AuthorDto> {
        return ok(service.createAuthor(dto))
    }

    override fun getAuthor(authorId: String): ResponseEntity<AuthorDto> {
        return ok(service.getAuthor(authorId))
    }

    override fun deleteAuthor(authorId: String): ResponseEntity<AuthorDto> {
        return ok(service.deleteAuthor(authorId))
    }

    override fun find(number: Int, size: Int, order: String, dir: String): ResponseEntity<Page<AuthorDto>> {
        return ok(service.find(number,size,order,dir))
    }
    override fun getAuthorBooks(authorId: String,number: Int, size: Int, order: String, dir: String): ResponseEntity<Page<String>> {
        return ok(service.getAuthorBooks(authorId,number, size, order, dir))
    }

    override fun addAuthorBook(authorId: String, bookId: String): ResponseEntity<String> {
        return ok(service.addAuthorBook(authorId,bookId))
    }

    override fun removeAuthorBook(authorId: String, bookId: String): ResponseEntity<String> {
        return ok(service.removeAuthorBook(authorId,bookId))
    }
}