package pt.unl.fct.di.iadidemo.presentation.controller

import org.springframework.data.domain.Page
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.RestController
import pt.unl.fct.di.iadidemo.presentation.api.BookInterface
import pt.unl.fct.di.iadidemo.presentation.dto.BookDto
import pt.unl.fct.di.iadidemo.presentation.dto.RateDto
import pt.unl.fct.di.iadidemo.presentation.dto.reviewDto
import pt.unl.fct.di.iadidemo.presentation.service.BookService

@RestController
class BookController(val service:BookService) : BookInterface, AbstractController() {

    override fun createBook(bookdto: BookDto): ResponseEntity<BookDto> {
        return ok(service.createBook(bookdto))
    }

    override fun getBook(bookId: String): ResponseEntity<BookDto> {
        return ok(service.getBook(bookId))
    }

    override fun deleteBook(bookId: String): ResponseEntity<BookDto> {
        return ok(service.deleteBook(bookId))
    }

    override fun find(number: Int, size: Int, order: String, dir: String): ResponseEntity<Page<BookDto>> {
        return ok(service.find(number,size,order,dir))
    }

    override fun rateBook(rate: RateDto): ResponseEntity<RateDto> {
        return ok(service.rateBook(rate))
    }

    override fun reviewBook(review: reviewDto): ResponseEntity<reviewDto> {
        return ok(service.reviewBook(review))
    }

}