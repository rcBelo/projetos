package pt.unl.fct.di.iadidemo.presentation.controller

import org.springframework.data.domain.Page
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import pt.unl.fct.di.iadidemo.presentation.api.UserInterface
import pt.unl.fct.di.iadidemo.presentation.dto.UserDto
import pt.unl.fct.di.iadidemo.presentation.service.UserService

@RestController
class UserController (val service: UserService) : UserInterface, AbstractController(){
    override fun createUser(dto: UserDto): ResponseEntity<UserDto> {
        return ok(service.createUser(dto))
    }

    override fun getUser(userId: String): ResponseEntity<UserDto> {
        return ok(service.getUser(userId))
    }

    override fun deleteUser(userId: String): ResponseEntity<UserDto> {
        return ok(service.deleteUser(userId))
    }

    override fun find(number: Int, size: Int, order: String, dir: String): ResponseEntity<Page<UserDto>> {
        return ok(service.find(number,size,order,dir))
    }

    override fun getFavBooks(
        userId: String,number: Int,size: Int, order: String, dir: String): ResponseEntity<Page<String>> {
        return ok(service.getFavBooks(userId, number, size, order, dir))
    }

    override fun addFavBook(userId: String, book: String) :ResponseEntity<String>{
        return ok(service.addFavBook(userId,book))
    }

    override fun removeFavBook(userId: String, book: String):ResponseEntity<String> {
        return ok(service.removeFavBook(userId,book))
    }


}