package pt.unl.fct.di.iadidemo.presentation.dto

import io.swagger.v3.oas.annotations.media.Schema

@Schema(name = "AuthorDTO")
class AuthorDto{
    @Schema(description = "Id of the author", name = "id", required = true)
    var id:String ?= null

    @Schema(description = "Name of the author",name="name", example = "Dan Brown", required=true)
    var name:String ?= null

    @Schema(description = "List of books from a author",name="books")
    var books:MutableList<String> ?= null

    constructor(id: String, name:String, books: MutableList<String>) {
        this.id = id
        this.name = name
        this.books = books;
    }

}
