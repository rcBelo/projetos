package pt.unl.fct.di.iadidemo.presentation.dto

import io.swagger.v3.oas.annotations.media.Schema
import pt.unl.fct.di.iadidemo.presentation.utils.rate
import pt.unl.fct.di.iadidemo.presentation.utils.review
@Schema(name = "BookDTO")
class BookDto{
    @Schema(description = "id of the book",name="id",required=true)
    var id:String ?= null

    @Schema(description = "Name of the book",name="name",required=true, example = "The Great Gatsby")
    var name:String ?= null

    @Schema(description = "Name of the author",name="author", example = "Fitzgerald")
    var author:String ?= null

    @Schema(description = "List of rates for a book",name="rates")
    var rates:MutableList<rate> ?= null

    @Schema(description = "List of reviews for a book",name="reviews")
    var reviews:MutableList<review> ?= null

    constructor(id: String, name:String,author:String, rates: MutableList<rate>, reviews: MutableList<review>) {
        this.id = id
        this.name = name
        this.rates = rates
        this.author = author
        this.reviews = reviews

    }


}
