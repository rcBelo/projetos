package pt.unl.fct.di.iadidemo.presentation.dto

import io.swagger.v3.oas.annotations.media.Schema
import org.springframework.format.annotation.NumberFormat
import javax.validation.constraints.NotEmpty
import javax.validation.constraints.Pattern
@Schema(name = "RateDTO")
class RateDto{
    @NotEmpty
    @Schema(description = "Id of the user",name="userId",required=true)
    var userId:String ?= null

    @NotEmpty
    @Schema(description = "Id of the boook",name="bookId",required=true)
    var bookId:String ?= null

    @Pattern(regexp="(1|2|3|4|5)")
    @Schema(description = "Book rating",name="rating",required=true, example = "2")
    var rating:Int ?= null

    constructor(userId: String, bookId:String, rating: Int) {
        this.userId = userId
        this.bookId = bookId
        this.rating = rating;
    }
}