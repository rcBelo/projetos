package pt.unl.fct.di.iadidemo.presentation.dto

import io.swagger.v3.oas.annotations.media.Schema
@Schema(name = "UserDTO")
class UserDto{
    @Schema(description = "Id of the user",name="id",required=true)
    var id:String ?= null

    @Schema(description = "Name of the user",name="name",required=true, example = "New York Times intern")
    var name:String ?= null

    @Schema(description = "List of the favorite books from a user",name="favBooks")
    var favBooks:MutableList<String> ?= null


    constructor(id: String, name:String, favBooks: MutableList<String>) {
        this.id = id
        this.name = name
        this.favBooks = favBooks;
    }
}
