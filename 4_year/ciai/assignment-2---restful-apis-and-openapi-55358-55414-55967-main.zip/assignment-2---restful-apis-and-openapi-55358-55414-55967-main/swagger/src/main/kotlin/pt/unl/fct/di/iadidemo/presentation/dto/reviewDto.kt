package pt.unl.fct.di.iadidemo.presentation.dto

import io.swagger.v3.oas.annotations.media.Schema
import pt.unl.fct.di.iadidemo.presentation.utils.review
import javax.validation.constraints.NotEmpty
@Schema(name = "ReviewDTO")
class reviewDto{
    @Schema(description = "Id of the user",name="userId",required=true)
    var userId:String ?= null

    @NotEmpty
    @Schema(description = "Id of the boook",name="bookId",required=true)
    var bookId:String ?= null

    @NotEmpty
    @Schema(description = "Book review",name="review",required=true, example = "This so could be made into film... loved it!")
    var review:String ?= null

    constructor(userId: String, bookId:String, review: String) {
        this.userId = userId
        this.bookId = bookId
        this.review = review;
    }
}