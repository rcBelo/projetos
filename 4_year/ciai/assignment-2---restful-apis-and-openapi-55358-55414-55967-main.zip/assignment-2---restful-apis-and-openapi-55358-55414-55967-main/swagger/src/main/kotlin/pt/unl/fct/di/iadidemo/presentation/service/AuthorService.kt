package pt.unl.fct.di.iadidemo.presentation.service

import org.springframework.data.domain.*
import org.springframework.stereotype.Service
import pt.unl.fct.di.iadidemo.presentation.dto.AuthorDto
import java.util.*
import java.util.Optional.empty

@Service
class AuthorService {
    val list = mutableListOf<AuthorDto>(
        AuthorDto("0","John", mutableListOf("B0","B1","B2")),
        AuthorDto("1","Michael", mutableListOf("B3","B4","B5")),
        AuthorDto("2","Peter", mutableListOf("B6")),
        AuthorDto("3","Joseph", mutableListOf("B7","B8")),
        AuthorDto("4","Mary", mutableListOf("B9")))

    fun createAuthor(dto: AuthorDto): Optional<AuthorDto> {
        list.add(dto)
        return Optional.of(dto)
    }
    fun getAuthor(id: String): Optional<AuthorDto> {
        return Optional.of(list[(0..4).random()])
    }

    fun deleteAuthor(id: String): Optional<AuthorDto> {
        val pos =(0..4).random()
        val author:AuthorDto = list[pos]
        list.removeAt(pos)
        return Optional.of(author)
    }



    fun find(number: Int, size: Int, order: String, dir: String): Optional<Page<AuthorDto>> {
        val pageable:Pageable =PageRequest.of(number,size, Sort.unsorted())
        return Optional.of(PageImpl<AuthorDto>(list,pageable,list.size.toLong()))
    }

    fun getAuthorBooks(authorId: String,number: Int, size: Int, order: String, dir: String): Optional<Page<String>> {
        val pageable:Pageable =PageRequest.of(number,size, Sort.unsorted())
        for(author in list){
            if(author.id == authorId)
                //return Optional.of(PageImpl<String>(author.books,pageable,author.books.size.toLong()))
                return empty()
        }
        return empty();
    }

    fun addAuthorBook(authorId: String, bookId: String): Optional<String> {
        for(author in list){
            if(author.id == authorId)
                author.books?.add(bookId)
        }
        return Optional.of(bookId)
    }

    fun removeAuthorBook(authorId: String, bookId: String): Optional<String> {
        for(author in list){
            if(author.id == authorId)
                author.books?.remove(bookId)
        }
        return Optional.of(bookId)
    }

}
