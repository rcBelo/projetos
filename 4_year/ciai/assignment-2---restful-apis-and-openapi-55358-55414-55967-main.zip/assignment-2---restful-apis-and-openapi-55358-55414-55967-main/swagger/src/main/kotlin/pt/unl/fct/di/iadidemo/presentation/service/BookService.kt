package pt.unl.fct.di.iadidemo.presentation.service

import org.springframework.data.domain.*
import org.springframework.stereotype.Service
import pt.unl.fct.di.iadidemo.presentation.dto.BookDto
import pt.unl.fct.di.iadidemo.presentation.dto.RateDto
import pt.unl.fct.di.iadidemo.presentation.dto.reviewDto
import pt.unl.fct.di.iadidemo.presentation.utils.rate
import pt.unl.fct.di.iadidemo.presentation.utils.review
import java.util.*

@Service
class BookService {
    val list = mutableListOf<BookDto>(
        BookDto("B0","NameB0","John", mutableListOf(rate("0",3),rate("1",4)),
            mutableListOf(review("0","Muito Bom"),review("1","Bom"))),
        BookDto("B1","NameB1","John", mutableListOf(rate("4",4),rate("1",3),rate("0",2)),
            mutableListOf(review("4","Muito Bom"),review("1","Bom"))),
        BookDto("B2","NameB2","John", mutableListOf(rate("3",3)),
            mutableListOf(review("3","Bom"),review("1","Bom"))),
        BookDto("B3","NameB3","Michael", mutableListOf(rate("1",5),rate("2",4),rate("0",5)),
            mutableListOf(review("1","Muito Bom"),review("2","Bom"))),
        BookDto("B4","NameB4","Michael", mutableListOf(rate("1",3),rate("3",3),rate("4",4)),
            mutableListOf(review("3","Mau"),review("0","Mau"))),
        BookDto("B5","NameB5","Michael", mutableListOf(rate("2",1)),
            mutableListOf(review("2","Nao gostei"),review("0","Bom"))),
        BookDto("B6","NameB6","Peter", mutableListOf(rate("2",1),rate("1",3)),
            mutableListOf()),
        BookDto("B7","NameB7","Joseph", mutableListOf(rate("2",3),rate("3",4),rate("0",4)),
            mutableListOf()),
        BookDto("B8","NameB8","Joseph", mutableListOf(rate("2",2)),
            mutableListOf()),
        BookDto("B9","NameB9","Mary", mutableListOf(rate("0",2),rate("2",2),rate("1",1)),
            mutableListOf(review("0","Mau"),review("2","Mau"),review("1","Nao gostei")))

    )

    fun createBook(dto: BookDto): Optional<BookDto> {
        list.add(dto)
        return Optional.of(dto)
    }

    fun getBook(id: String): Optional<BookDto> {
        return Optional.of(list[(0..4).random()])
    }

    fun deleteBook(id: String): Optional<BookDto> {
        val pos =(0..4).random()
        val book:BookDto = list[pos]
        list.removeAt(pos)
        return Optional.of(book)
    }

    fun find(number: Int, size: Int, order: String, dir: String): Optional<Page<BookDto>> {
        val pageable: Pageable = PageRequest.of(number,size, Sort.unsorted())
        return Optional.of(PageImpl<BookDto>(list,pageable,list.size.toLong()))
    }

    fun reviewBook(review: reviewDto): Optional<reviewDto> {
        for(book in list){
            if(book.id == review.bookId)
                if(review.userId !== null && review.review !== null)
                    book.reviews?.add(review(review.userId!!, review.review!!))
        }
        return Optional.of(review)
    }

    fun rateBook(rate: RateDto): Optional<RateDto> {
        for(book in list){
            if(book.id == rate.bookId)
                if(rate.userId !== null && rate.rating !== null)
                    book.rates?.add(rate(rate.userId!!, rate.rating!!))
        }
        return Optional.of(rate)
    }


}
