package pt.unl.fct.di.iadidemo.presentation.service

import org.springframework.data.domain.*
import org.springframework.stereotype.Service
import pt.unl.fct.di.iadidemo.presentation.dto.UserDto
import java.util.*
import java.util.Optional.empty


@Service
class UserService {
    val list = mutableListOf<UserDto>(UserDto("0","Joao", mutableListOf("a","b")),
        UserDto("1","Miguel", mutableListOf("a","b")),
        UserDto("2","Pedro", mutableListOf("a","b")),
        UserDto("3","José", mutableListOf("a","b")),
        UserDto("4","Maria", mutableListOf("a","b")))

    fun createUser(dto: UserDto): Optional<UserDto> {
        list.add(dto)
        return Optional.of(dto)
    }

    fun getUser(userId: String): Optional<UserDto> {
        return Optional.of(list[(0..4).random()])
    }

    fun deleteUser(userId: String): Optional<UserDto> {
        val pos =(0..4).random()
        val user: UserDto = list[pos]
        list.removeAt(pos)
        return Optional.of(user)
    }

    fun find(number: Int, size: Int, order: String, dir: String): Optional<Page<UserDto>> {
        val pageable: Pageable = PageRequest.of(number,size, Sort.unsorted())
            return Optional.of(PageImpl<UserDto>(list,pageable,list.size.toLong()))
    }
    fun getFavBooks(userId:String,number: Int, size: Int, order: String, dir: String): Optional<Page<String>> {
        val pageable: Pageable = PageRequest.of(number,size, Sort.unsorted())
        for(v in list){
            if(v.id == userId)
                //return Optional.of(PageImpl<String>(v.favBooks,pageable,v.favBooks.size.toLong()))
                return empty()
        }
        return empty();
    }

    fun addFavBook(userId: String, book: String): Optional<String> {
        for(v in list){
            if(v.id == userId)
                v.favBooks?.add(book);
        }
        return Optional.of(book);
    }

    fun removeFavBook(userId: String, book: String): Optional<String> {
        for(v in list){
            if(v.id == userId)
                v.favBooks?.remove(book);
        }
        return Optional.of(book);
    }

}
