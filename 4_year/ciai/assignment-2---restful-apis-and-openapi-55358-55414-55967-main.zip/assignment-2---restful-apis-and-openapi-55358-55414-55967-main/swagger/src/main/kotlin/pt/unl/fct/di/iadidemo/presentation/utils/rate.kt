package pt.unl.fct.di.iadidemo.presentation.utils

class rate(
    var userId:String,
    var rate:Int
) {
}