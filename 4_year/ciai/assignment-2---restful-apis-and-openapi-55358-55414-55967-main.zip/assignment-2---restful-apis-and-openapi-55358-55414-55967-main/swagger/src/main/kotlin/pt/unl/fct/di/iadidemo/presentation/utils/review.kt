package pt.unl.fct.di.iadidemo.presentation.utils

class review(
    var userId:String,
    var text:String

) {
}