package pt.unl.fct.di.iadidemo

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class IadidemoApplicationTests {

    @Test
    fun contextLoads() {
    }

}
