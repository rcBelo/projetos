package pt.unl.fct.di.iadidemo.api

import org.springframework.web.bind.annotation.*
import pt.unl.fct.di.iadidemo.architecture.api.GenAPI
import pt.unl.fct.di.iadidemo.architecture.api.dto.*

@RequestMapping("books")
interface BooksAPI : GenAPI<BookDTO,BookListDTO,BookListDTO> {

    @GetMapping("{id}/reviews")
    fun getReviews(@PathVariable id:Long):List<ReviewBookDTO>

    @PostMapping("{id}/reviews")
    fun addReview(@PathVariable id:Long, @RequestBody review: ReviewDTO):List<ReviewBookDTO>

    @GetMapping("{id}/reviews/{rid}")
    fun getReviewOfBook(@PathVariable id:Long, @PathVariable rid:Long): ReviewBookLongDTO

    @PutMapping("{id}/reviews/{rid}")
    fun updateReviewOfBook(@PathVariable id:Long, @PathVariable rid:Long, @RequestBody review: ReviewDTO):Unit

    @DeleteMapping("{id}/reviews/{rid}")
    fun deleteReviewOfBook(@PathVariable id:Long, @PathVariable rid:Long):Unit
}