package pt.unl.fct.di.iadidemo.architecture.controllers

import org.springframework.http.HttpStatus
import org.springframework.web.bind.annotation.RestController
import org.springframework.web.server.ResponseStatusException
import pt.unl.fct.di.iadidemo.api.BooksAPI
import pt.unl.fct.di.iadidemo.architecture.api.dto.*
import pt.unl.fct.di.iadidemo.architecture.model.BookDAO
import pt.unl.fct.di.iadidemo.architecture.model.ReviewDAO
import pt.unl.fct.di.iadidemo.architecture.services.BookService
import java.util.*

/**
 * This is a sample class implementing the presentation logic layer for REST services,
 * the controller layer.
 *
 * Each controller implements a set of endpoints declared in a API interface. It performs
 * data format transformation and prepares answers to the REST clients.
 *
 * This controller implements two sample endpoints that use and orchestrate methods
 * from one or more components from the service layer. Notice the use of DTO classes
 * to define the types of the enpoint parameters and results. Data transformations are
 * necessary in all cases.
 */

@RestController
class BookController(val books: BookService) : BooksAPI {

    override fun getAll(): List<BookListDTO> =
        books.getAll().map {
            BookListDTO(it.id, it.title, it.authors.map {
                AuthorsBookDTO(it.name)
            },
                it.reviews.map { ReviewBookDTO(it.id, it.review, it.rating, it.user.username) });
        };

    override fun addOne(book: BookDTO): Unit =
        books.addOne(BookDAO(0, book.title, emptyList(), mutableListOf()));

    override fun getOne(id: Long): BookListDTO =
        books
            .getOne(id)
            .orElseThrow { ResponseStatusException(HttpStatus.NOT_FOUND, "Book not found ${id}") }
            .let {
                BookListDTO(
                    it.id,
                    it.title,
                    it.authors.map { AuthorsBookDTO(it.name) },
                    it.reviews.map { ReviewBookDTO(it.id, it.review, it.rating, it.user.username) }
                )
            }

    override fun updateOne(id: Long, elem: BookDTO) {
    books.updateOne(id,elem)
}


    override fun deleteOne(id: Long) =
        books.deleteOne(id)


    override fun getReviews(id: Long): List<ReviewBookDTO> =
        books.getReviews(id).map{
            ReviewBookDTO(
                it.id,
                it.review,
                it.rating,
                it.user.username)
        }


    override fun addReview(id: Long, review: ReviewDTO): List<ReviewBookDTO> =
       books.addReview(id,review).map{
           ReviewBookDTO(
               it.id,
               it.review,
               it.rating,
               it.user.username)}


    override fun getReviewOfBook(id: Long, rid: Long): ReviewBookLongDTO =
        books
            .getReviewOfBook(id,rid)
            .orElseThrow{ResponseStatusException(HttpStatus.NOT_FOUND, "Book or Review not found ${id}")}
            .let{
                ReviewBookLongDTO(
                    it.review,
                    it.rating,
                    it.user.username,
                    id
                )

        }

    override fun updateReviewOfBook(id: Long, rid: Long, review: ReviewDTO) {
        books.updateReviewOfBook(id,rid, review)
    }

    override fun deleteReviewOfBook(id: Long, rid: Long) {
        books.deleteReviewOfBook(id,rid)
    }
}