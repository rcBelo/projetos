package pt.unl.fct.di.iadidemo.architecture.model

import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Modifying
import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.CrudRepository
import pt.unl.fct.di.iadidemo.architecture.api.dto.ReviewBookDTO
import java.util.*

interface BookRepository : JpaRepository<BookDAO, Number> {

    /*// must define a query to efficiently retrive reviews of a given book
    @Query("select p.reviews from BookDAO p inner join p.reviews where p.id = :id")
    fun getReviewDAOByBookId(id:Long) : List<ReviewDAO>

    @Query("select p from BookDAO p inner join fetch p.reviews where p.id = :id")
    fun getbookAndReview(id:Long) : Optional<BookDAO>

    @Query("select r from ReviewDAO r inner join fetch r.book b where b.id = :id and r.id = :rid")
    fun getBookAndReviewsbyId(id:Long, rid:Long) : Optional<ReviewDAO>

    @Query("select r from ReviewDAO r inner join r.book b where b.id = :id and r.id = :rid")
    fun getReviewDAOByBookIdAndReviewId(id:Long, rid:Long) : Optional<ReviewDAO>*/

    //dfghjkjhgfdsdfghjklkjhgfdfghjkkjhgf

    @Query("select r from ReviewDAO r join r.book b where b.id = :id")
    fun getReviewDAOByBookId(id:Long) : List<ReviewDAO>

    @Query("select r from ReviewDAO r inner join r.book b where b.id = :id and r.id = :rid")
    fun getReviewDAOByBookIdAndReviewId(id:Long, rid:Long) : Optional<ReviewDAO>


    //Spring nao suporta deletes com joins, optei por simplesmente eliminar a review pelo repositorio de reviews
    //@Query("select r from ReviewDAO r inner join r.book b where b.id = :id and r.id = :rid")
    //fun getReviewDAOByBookIdAndReviewId(id:Long, rid:Long) : Optional<ReviewDAO>


    /*@Query("delete from User u where u.role.id = ?1")
    @Query("delete from ReviewDAO r where r.rating = :rat")
    fun deleteReviewByRating(rat:Number): Optional<ReviewDAO>
    @Query("select b from BookDAO b inner join fetch b.reviews where b.id=:id")
    fun findByIdWithReview(id:Long):Optional<BookDAO>

    @Query("delete from ReviewDAO r inner join r.book b where b.id = :id and r.id = :rid")
    fun deleteReviewDAOByBookIdAndReviewId(id:Long, rid:Long):List<ReviewDAO>*/
}
