package pt.unl.fct.di.iadidemo.architecture.model

import pt.unl.fct.di.iadidemo.architecture.api.dto.BookDTO
import pt.unl.fct.di.iadidemo.architecture.api.dto.ReviewDTO
import javax.persistence.*

@Entity
data class BookDAO(
    @Id @GeneratedValue
    val id:Long,

    var title:String,

    @ManyToMany
    val authors:List<AuthorDAO>,

    @OneToMany(orphanRemoval = true,cascade = [CascadeType.ALL])
    var reviews:MutableList<ReviewDAO>

    ) {
    fun update(elem: BookDTO) {
        if(elem.title!=null)
            title=elem.title
    }
}


@Entity
data class AuthorDAO(
    @Id @GeneratedValue
    val id:Long,

    val name:String,

    @ManyToMany
    val books:List<BookDAO>
    )

@Entity
data class ReviewDAO(
    @Id @GeneratedValue
    val id:Long,

    var review:String,

    var rating:Number,

    @ManyToOne(cascade = [CascadeType.PERSIST])
    val book:BookDAO,

    @ManyToOne(fetch = FetchType.LAZY)
    val user:UserDAO
    ) {
    fun update(review: ReviewDTO) {
            if(review.message!=null)
                this.review=review.message
            if(review.rating!=null)
                this.rating=review.rating
    }
}

@Entity
data class UserDAO(
    @Id
    val username:String,

    val name:String,

    @OneToMany
    val reviews: List<ReviewDAO>
    )