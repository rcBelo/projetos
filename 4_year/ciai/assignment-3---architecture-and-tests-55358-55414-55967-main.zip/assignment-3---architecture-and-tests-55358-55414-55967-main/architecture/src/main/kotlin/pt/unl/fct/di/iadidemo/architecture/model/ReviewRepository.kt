package pt.unl.fct.di.iadidemo.architecture.model

import org.springframework.data.jpa.repository.JpaRepository
import java.util.*

interface ReviewRepository: JpaRepository<ReviewDAO, Number> {

    fun findAllByBook_Id(id:Long):Optional<List<ReviewDAO>>

    fun findByBook_IdAndId(id:Long, rid:Long): Optional<ReviewDAO>

    fun deleteByBook_IdAndId(id:Long, rid:Long)

}