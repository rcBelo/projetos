package pt.unl.fct.di.iadidemo.architecture.model

import org.springframework.data.jpa.repository.JpaRepository

interface UserRepository : JpaRepository<UserDAO, Number> {

}
