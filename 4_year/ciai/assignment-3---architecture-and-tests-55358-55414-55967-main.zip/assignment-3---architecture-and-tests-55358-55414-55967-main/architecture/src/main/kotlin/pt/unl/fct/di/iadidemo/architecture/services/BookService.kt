package pt.unl.fct.di.iadidemo.architecture.services

import org.springframework.http.HttpStatus
import org.springframework.stereotype.Service
import org.springframework.web.server.ResponseStatusException
import pt.unl.fct.di.iadidemo.architecture.api.dto.BookDTO
import pt.unl.fct.di.iadidemo.architecture.api.dto.ReviewBookDTO
import pt.unl.fct.di.iadidemo.architecture.api.dto.ReviewBookLongDTO
import pt.unl.fct.di.iadidemo.architecture.api.dto.ReviewDTO
import pt.unl.fct.di.iadidemo.architecture.model.*
import java.util.*

/**
 * This is a sample class implementing the application logic layer, the service layer.
 *
 * Each service should implement logic that is closely related. It can use
 * other services to orchestrate its functionality.
 *
 * This service declares a dependency for the repository service in the data
 * layer that manipulates the information about books. Notice that the class
 * is annotated with @Service so that Spring can instantiate the corresponding
 * Bean and connect to other components.
 *
 * This implements two sample methods that use and orchestrate methods from the
 * database repository. It can also perform intermediate computations to prepare
 * data.
 */
@Service
class BookService(val books:BookRepository,val users: UserRepository,val reviews: ReviewRepository) {

    fun getAll(): List<BookDAO> = books.findAll().toList()

    fun addOne(book: BookDAO): Unit {
        books.save(book)
    }

    fun getOne(id: Long): Optional<BookDAO> = books.findById(id)


    fun updateOne(id: Long, elem: BookDTO): Optional<BookDAO> {
        val book = getBook(id)
        book.update(elem)
        return Optional.of(books.save(book))

    }

    fun deleteOne(id: Long) {
        books.deleteById(id)
    }

    fun getReviews(id: Long): List<ReviewDAO> = books.getReviewDAOByBookId(id)


    fun addReview(id: Long, review: ReviewDTO): List<ReviewDAO> {
        var book = getBook(id)
        var user = UserDAO("ruben", "ruben belo", emptyList())
        users.save(user)
        var dao = ReviewDAO(0, review.message, review.rating, book, user)
        book.reviews.add(dao)

        return books.save(book).reviews
    }

    fun getReviewOfBook(id: Long, rid: Long): Optional<ReviewDAO> = books.getReviewDAOByBookIdAndReviewId(id,rid);



    fun updateReviewOfBook(id: Long, rid: Long, review: ReviewDTO) :Optional<ReviewDAO>{
        var dao=getReview(id,rid)
        dao.update(review)
        return Optional.of(reviews.save(dao))
    }

    fun deleteReviewOfBook(id: Long, rid: Long) {
        var b =getBook(id)
        b.reviews.remove(getReview(id,rid))
        books.save(b)
    }
    private fun getBook(id: Long): BookDAO{
        return books.findById(id).orElseThrow { ResponseStatusException(HttpStatus.NOT_FOUND, "Book not found ${id}") }

    }
    private fun getReview(id:Long, rid: Long): ReviewDAO{
        return books.getReviewDAOByBookIdAndReviewId(id,rid).orElseThrow{ResponseStatusException(HttpStatus.NOT_FOUND, "Book or Review not found")}

    }
}
