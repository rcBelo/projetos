package pt.unl.fct.di.iadidemo.architecture

import com.fasterxml.jackson.databind.ObjectMapper
import org.junit.Assert
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mockito
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.boot.test.mock.mockito.MockBean
import org.springframework.http.HttpStatus
import org.springframework.http.MediaType
import org.springframework.test.context.junit4.SpringRunner
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*
import org.springframework.test.web.servlet.result.MockMvcResultMatchers.content
import org.springframework.test.web.servlet.result.MockMvcResultMatchers.status
import pt.unl.fct.di.iadidemo.architecture.api.dto.BookDTO
import pt.unl.fct.di.iadidemo.architecture.api.dto.ReviewBookDTO
import pt.unl.fct.di.iadidemo.architecture.api.dto.ReviewBookLongDTO
import pt.unl.fct.di.iadidemo.architecture.api.dto.ReviewDTO
import pt.unl.fct.di.iadidemo.architecture.model.BookDAO
import pt.unl.fct.di.iadidemo.architecture.model.ReviewDAO
import pt.unl.fct.di.iadidemo.architecture.model.UserDAO
import pt.unl.fct.di.iadidemo.architecture.services.BookService
import java.awt.print.Book
import java.util.*


@RunWith(SpringRunner::class)
@SpringBootTest
@AutoConfigureMockMvc
class BookControllerTests {

    @Autowired
    lateinit var mvc:MockMvc

    @MockBean
    lateinit var books: BookService

    companion object {
        val b0 = BookDAO(0,"LOR", emptyList(), mutableListOf())
        val b1 = BookDAO(1,"LOR", emptyList(), mutableListOf())
        val b2 = BookDAO(2, "Dune", emptyList(), mutableListOf())

        var user = UserDAO("ruben", "ruben belo", emptyList())


        val r1 = ReviewDAO(1,"muito giro",4, b1, user)

        val r2 = ReviewDAO(2,"mais ou menos",2, b1, user)

        val r3 = ReviewDAO(3,"mau",1, b1, user)

        val review = ReviewDTO("mau",1)

        val r1DTO = ReviewBookDTO(1,"muito giro",4, "ruben")

        val rLongDTO = ReviewBookLongDTO("muito giro",4, "ruben", 1)

        val r2DTO = ReviewBookDTO(2,"mais ou menos",2,  "ruben")

        val r3DTO = ReviewBookDTO(3,"mau",1,  "ruben")

        val rDTO = listOf<ReviewBookDTO>(r1DTO,r2DTO,r3DTO)

        val r = listOf<ReviewDAO>(r1,r2,r3)

        val l = listOf<BookDAO>(b1,b2)

        val mapper = ObjectMapper()

        val s1 = mapper.writeValueAsString(l)

        val Sb1 = mapper.writeValueAsString(b1)

        val b1DTOJSON = mapper.writeValueAsString(BookDTO("LOR"))

        val r1DTOJson = mapper.writeValueAsString(r1DTO)

        val stringRDTO = mapper.writeValueAsString(rDTO)

        val stringRLongDTO = mapper.writeValueAsString(rLongDTO)

    }

    @Test
    fun `Test GET book`() {
        Mockito.`when`(books.getOne(1)).thenReturn(Optional.of(b1))

        val s =
            mvc.perform(get("/books/1"))
                .andExpect(status().isOk())
                .andExpect(content().string(Sb1))
                .andReturn()

        println(b1)
        println(s.response.contentAsString)
    }

    @Test
    fun `Test fail GET book`() {
        Mockito.`when`(books.getOne(1)).thenReturn(Optional.of(b1))

        val s =
            mvc.perform(get("/books/2"))
                .andExpect(status().isNotFound)
                .andReturn()

        println(b1)
        println(s.response.contentAsString)
    }

    @Test
    fun `Delete book`() {
        Mockito.`when`(books.deleteOne(1)).then {  }


        val d = mvc.perform(delete("/books/1"))
            .andExpect(status().isOk())

    }



    @Test
    fun `Test UpdateBook`() {

        val dto = BookDTO("o regresso daqueles q nnc foram")
        val dao = BookDAO(1,"o regresso daqueles q nnc foram", emptyList(), mutableListOf())


        Mockito.`when`(books.updateOne(1, dto)).thenReturn(Optional.of(dao))

        val dtoJson = mapper.writeValueAsString(dto)
           mvc.perform(put("/books/1").contentType(MediaType.APPLICATION_JSON)
                .content(dtoJson))
                .andExpect(status().isOk())

    }

    @Test
    fun `Test UpdateReview`() {

        val dto = ReviewDTO("muito giro", 4)
        val dao = ReviewDAO(2,"muito giro",4, b1, user)
        Mockito.`when`(books.updateReviewOfBook(1, 2, dto)).thenReturn(Optional.of(dao))

        val dtoJson = mapper.writeValueAsString(dto)
        mvc.perform(put("/books/1/reviews/2").contentType(MediaType.APPLICATION_JSON)
            .content(dtoJson))
            .andExpect(status().isOk())

    }

    @Test
    fun `Delete review`() {
        Mockito.`when`(books.deleteReviewOfBook(1, 2)).then {  }


        val d = mvc.perform(delete("/books/1/reviews/2"))
            .andExpect(status().isOk())

    }

    @Test
    fun `Test GET reviews`() {
        Mockito.`when`(books.getReviews(1)).thenReturn(r)

        val s =
            mvc.perform(get("/books/1/reviews"))
                .andExpect(status().isOk())
                .andExpect(content().string(stringRDTO))
                .andReturn()

        println(rDTO)
        println(s.response.contentAsString)
    }

    @Test
    fun `Test GET review`() {
        Mockito.`when`(books.getReviewOfBook(1,2)).thenReturn(Optional.of(r1))

        val s =
            mvc.perform(get("/books/1/reviews/2"))
                .andExpect(status().isOk())
                .andExpect(content().string(stringRLongDTO))
                .andReturn()

        println(rLongDTO)
        println(s.response.contentAsString)
    }

    @Test
    fun `Test fail GET review`() {
        Mockito.`when`(books.getReviewOfBook(1,2)).thenReturn(Optional.of(r1))

        val s =
            mvc.perform(get("/books/1/reviews/4"))
                .andExpect(status().isNotFound)
                .andReturn()

        println(rLongDTO)
        println(s.response.contentAsString)
    }

    @Test
    fun `Test GET books`() {
        Mockito.`when`(books.getAll()).thenReturn(l)

        val s =
            mvc.perform(get("/books"))
                .andExpect(status().isOk())
                .andExpect(content().string(s1))
                .andReturn()

        println(l)
        println(s.response.contentAsString)
    }

    fun <T>nonNullAny(t:Class<T>):T = Mockito.any(t);

    @Test
    fun `add one test`(){
        Mockito.`when`(books.addOne(nonNullAny(BookDAO::class.java)))
            .then {
            val o = it.getArgument<BookDAO>(0)
        Assert.assertEquals(o,b0)
            }


        mvc.perform(post("/books")
            .contentType(MediaType.APPLICATION_JSON)
            .content(b1DTOJSON))
            .andExpect(status().isOk)
    }

    @Test
    fun `add one review test`(){
        Mockito.`when`(books.addReview(1, review)).thenReturn(r)



        val s = mvc.perform(post("/books/1/reviews")
            .contentType(MediaType.APPLICATION_JSON)
            .content(mapper.writeValueAsString(review)))
            .andExpect(content().string(stringRDTO))
            .andExpect(status().isOk).andReturn()

        println(s.response.contentAsString)
        println(r)
    }
}