package pt.unl.fct.di.iadidemo.security

import org.springframework.boot.CommandLineRunner
import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder
import pt.unl.fct.di.iadidemo.security.domain.*

@SpringBootApplication
class SecurityApplication(val books:BookRepository, val users:UserRepository, val reviews:ReviewRepository) : CommandLineRunner {
    override fun run(vararg args: String?) {

        println(BCryptPasswordEncoder().encode("password1"))
        val u1 = UserDAO("user1",BCryptPasswordEncoder().encode("password1"), listOf("USER"),
            mutableListOf(),"User 1", emptyList(), emptyList())
        users.save(u1)

        val u2 = UserDAO("admin1",BCryptPasswordEncoder().encode("password1"), listOf("ADMIN"), mutableListOf(),"Admin 1", emptyList(), emptyList())
        users.save(u2)

        val u3 = UserDAO("editor1",BCryptPasswordEncoder().encode("password1"),listOf("EDITOR"),
            mutableListOf(), "Editor 1", emptyList(), emptyList())



        val b = BookDAO(0,"LOR","description1" ,emptyList(), mutableListOf(), u3)
        val r = ReviewDAO(0,"muito fixe", 5, b, u1)
        val r1 = ReviewDAO(0,"muito fixe", 5, b, u1)
        val r2 = ReviewDAO(0,"muito fixe", 5, b, u1)
        val r3 = ReviewDAO(0,"muito fixe", 5, b, u1)
        val r4 = ReviewDAO(0,"muito fixe", 5, b, u1)
        val r5 = ReviewDAO(0,"muito fixe", 5, b, u1)
        val r6 = ReviewDAO(0,"muito fixe", 5, b, u1)
        val r7 = ReviewDAO(0,"muito fixe", 5, b, u1)
        val r8 = ReviewDAO(0,"muito fixe", 5, b, u1)
        val r9 = ReviewDAO(0,"muito fixe", 5, b, u1)
        val r10 = ReviewDAO(0,"muito fixe", 5, b, u1)



        u3.reviews.plus(r)
        u3.reviews.plus(r1)
        u3.reviews.plus(r2)
        u3.reviews.plus(r3)
        u3.reviews.plus(r4)
        u3.reviews.plus(r5)
        u3.reviews.plus(r6)
        u3.reviews.plus(r7)
        u3.reviews.plus(r8)
        u3.reviews.plus(r9)
        u3.reviews.plus(r10)

        users.save(u3)
        b.reviews.add(r)
        b.reviews.add(r1)
        b.reviews.add(r2)
        b.reviews.add(r3)
        b.reviews.add(r4)
        b.reviews.add(r5)
        b.reviews.add(r6)
        b.reviews.add(r7)
        b.reviews.add(r8)
        b.reviews.add(r9)
        b.reviews.add(r10)

        books.save(b)

        reviews.save(r)
        reviews.save(r1)
        reviews.save(r2)
        reviews.save(r3)
        reviews.save(r4)
        reviews.save(r5)
        reviews.save(r6)
        reviews.save(r7)
        reviews.save(r8)
        reviews.save(r9)
        reviews.save(r10)

        println(u3)

    }

}

fun main(args: Array<String>) {
    runApplication<SecurityApplication>(*args)
}
