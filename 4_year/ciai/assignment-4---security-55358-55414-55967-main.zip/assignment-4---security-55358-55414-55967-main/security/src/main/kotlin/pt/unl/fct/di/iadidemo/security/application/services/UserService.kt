package pt.unl.fct.di.iadidemo.security.application.services

import org.springframework.http.HttpStatus
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder
import org.springframework.stereotype.Service
import org.springframework.web.server.ResponseStatusException
import pt.unl.fct.di.iadidemo.security.domain.UserDAO
import pt.unl.fct.di.iadidemo.security.domain.UserRepository
import java.util.*

@Service
class UserService(val users: UserRepository) {

    fun findUser(username:String) = users.findById(username)

    fun addUser(user: UserDAO) : Optional<UserDAO> {
        val aUser = users.findById(user.username)

        return if ( aUser.isPresent )
            Optional.empty()
        else {
            var sessionId=UUID.randomUUID().toString()
            if(user.sessions==null) user.sessions= mutableListOf()
            if(user.reviews==null) user.reviews= mutableListOf()
            if(user.books==null) user.books= mutableListOf()
            user.sessions.add(sessionId)
            user.role= listOf("USER")
            user.password = BCryptPasswordEncoder().encode(user.password)
            println(user)
            Optional.of(users.save(user))
        }
    }

    fun addSession(u:UserDAO, sessionId:String){
        val user = getSessions(u.username)
        user.sessions.add(sessionId);
        users.save(user);
    }
    fun getSessions(username:String)= users.getSession(username).orElseThrow{ ResponseStatusException(HttpStatus.NOT_FOUND, "User not found") }

    /*private fun  getSessions(u:UserDAO):UserDAO{
        var user= users.getSession(u.username).orElse(u)
        user.sessions= mutableListOf()
        return user
    }*/

    fun deleteSession(u:UserDAO, sessionId:String){
        val user = getSessions(u.username)
        user.sessions.remove(sessionId);
        users.save(user);
    }
}