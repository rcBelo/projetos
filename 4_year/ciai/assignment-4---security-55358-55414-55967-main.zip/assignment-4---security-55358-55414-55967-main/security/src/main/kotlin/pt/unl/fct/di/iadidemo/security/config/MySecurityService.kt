package pt.unl.fct.di.iadidemo.security.config

import org.springframework.http.HttpStatus
import org.springframework.security.core.context.SecurityContextHolder
import org.springframework.stereotype.Component
import org.springframework.web.server.ResponseStatusException
import pt.unl.fct.di.iadidemo.security.domain.BookRepository
import pt.unl.fct.di.iadidemo.security.domain.ReviewRepository
import pt.unl.fct.di.iadidemo.security.domain.UserDAO
import pt.unl.fct.di.iadidemo.security.domain.UserRepository


@Component("mySecurityService")
class MySecurityService(val reviews: ReviewRepository, val books:BookRepository) {

    fun canUpdateReview(user:UserAuthToken,id: Long) : Boolean {
        return reviews.existsByIdAndUser_Username(id,user.name)
    }
    fun canUpdateBook(user:UserAuthToken,id: Long) : Boolean {
        return books.existsByIdAndOwner_Username(id, user.name)
    }

    fun moreThan10(user:UserAuthToken) : Boolean {
        return reviews.countByUser_Username(user.name) > 10
    }
}