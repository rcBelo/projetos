package pt.unl.fct.di.iadidemo.security.domain

import org.springframework.data.jpa.repository.JpaRepository

interface AuthorRepository: JpaRepository<AuthorDAO, Number> {

    /*fun findAllByBook_Id(id:Long):Optional<List<ReviewDAO>>

    fun findByBook_IdAndId(id:Long, rid:Long): Optional<ReviewDAO>

    fun deleteByBook_IdAndId(id:Long, rid:Long)*/

}