package pt.unl.fct.di.iadidemo.security.domain

import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.CrudRepository
import java.util.*

interface BookRepository : CrudRepository<BookDAO, Number> {

    @Query("select r from ReviewDAO r join r.book b where b.id = :id")
    fun getReviewDAOByBookId(id:Long) : List<ReviewDAO>

    @Query("select r from ReviewDAO r inner join r.book b where b.id = :id and r.id = :rid")
    fun getReviewDAOByBookIdAndReviewId(id:Long, rid:Long) : Optional<ReviewDAO>

    fun existsByIdAndOwner_Username(id:Long, Username:String): Boolean
}