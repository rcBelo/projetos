package pt.unl.fct.di.iadidemo.security.domain

import pt.unl.fct.di.iadidemo.security.presentation.api.dto.BookDTO
import pt.unl.fct.di.iadidemo.security.presentation.api.dto.ReviewDTO
import javax.persistence.*

@Entity
data class BookDAO(
    @Id @GeneratedValue
    val id:Long,

    var title:String,

    var description:String,

    @ManyToMany
    val authors:List<AuthorDAO>,

    @OneToMany(orphanRemoval = true,cascade = [CascadeType.ALL])
    var reviews:MutableList<ReviewDAO>,

    @ManyToOne
    val owner: UserDAO

) {
    fun update(elem: BookDTO) {
        if(elem.title!=null)
            title=elem.title
    }
}


@Entity
data class AuthorDAO(
    @Id @GeneratedValue
    val id:Long,

    val name:String,

    @ManyToMany
    val books:List<BookDAO>
    )

@Entity
data class ReviewDAO(
    @Id @GeneratedValue
    val id:Long,

    var review:String,

    var rating:Number,

    @ManyToOne(cascade = [CascadeType.PERSIST])
    val book:BookDAO,

    @ManyToOne(fetch = FetchType.LAZY)
    val user:UserDAO
) {
    fun update(review: ReviewDTO) {
        if(review.message!=null)
            this.review=review.message
        if(review.rating!=null)
            this.rating=review.rating
    }
}

@Entity
data class UserDAO(
    @Id
    val username:String,

    var password:String,

    @ElementCollection(fetch=FetchType.EAGER)
    var role:List<String>,

   @ElementCollection()
    var sessions:MutableList<String>,

    val name:String,

    @OneToMany
    var reviews: List<ReviewDAO>,

    @OneToMany
    var books:List<BookDAO>

    )
