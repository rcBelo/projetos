package pt.unl.fct.di.iadidemo.security.domain

import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.Query
import java.util.*

interface ReviewRepository: JpaRepository<ReviewDAO, Number> {

    fun existsByIdAndUser_Username(id:Long,Username:String): Boolean

    fun countByUser_Username(Username:String): Int

    /*fun findAllByBook_Id(id:Long):Optional<List<ReviewDAO>>

    fun findByBook_IdAndId(id:Long, rid:Long): Optional<ReviewDAO>

    fun deleteByBook_IdAndId(id:Long, rid:Long)*/

}