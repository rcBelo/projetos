package pt.unl.fct.di.iadidemo.security.domain

import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.CrudRepository
import java.util.*

interface UserRepository : CrudRepository<UserDAO,String> {

    @Query("select u from UserDAO u left outer join fetch u.sessions where u.username = :username")
    fun getSession(username: String) : Optional<UserDAO>

    //fun findByUsername(username:String,id:String): UserDAO
}