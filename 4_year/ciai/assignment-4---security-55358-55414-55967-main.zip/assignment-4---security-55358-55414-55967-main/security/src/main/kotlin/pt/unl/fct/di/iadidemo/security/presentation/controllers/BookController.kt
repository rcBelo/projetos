package pt.unl.fct.di.iadidemo.security.presentation.controllers

import org.springframework.http.HttpStatus
import org.springframework.security.access.prepost.PreAuthorize
import org.springframework.security.core.context.SecurityContextHolder
import org.springframework.security.core.userdetails.UserDetails
import org.springframework.web.bind.annotation.RestController
import org.springframework.web.server.ResponseStatusException
import pt.unl.fct.di.iadidemo.security.application.services.BookService
import pt.unl.fct.di.iadidemo.security.config.CustomUserDetails
import pt.unl.fct.di.iadidemo.security.config.UserAuthToken
import pt.unl.fct.di.iadidemo.security.domain.BookDAO
import pt.unl.fct.di.iadidemo.security.domain.UserDAO
import pt.unl.fct.di.iadidemo.security.presentation.api.BooksAPI
import pt.unl.fct.di.iadidemo.security.presentation.api.dto.*


/**
 * This is a sample class implementing the presentation logic layer for REST services,
 * the controller layer.
 *
 * Each controller implements a set of endpoints declared in a API interface. It performs
 * data format transformation and prepares answers to the REST clients.
 *
 * This controller implements two sample endpoints that use and orchestrate methods
 * from one or more components from the service layer. Notice the use of DTO classes
 * to define the types of the enpoint parameters and results. Data transformations are
 * necessary in all cases.
 */

@RestController
class BookController(val books: BookService) : BooksAPI {

    override fun getAll(): List<BookListDTO> {
        var book = books.getAll()

        println(SecurityContextHolder.getContext().authentication.principal)

        if (SecurityContextHolder.getContext().authentication.principal != "anonymousUser") {
            return book.map {
                BookListDTO(it.id, it.title, it.authors.map {
                    AuthorsBookDTO(it.name)
                },
                    it.reviews.map { ReviewBookDTO(it.id, it.review, it.rating, it.user.username) })
            }
        } else {
            return book.map {
                BookListDTO(
                    it.id, it.title, it.authors.map {
                        AuthorsBookDTO(it.name)
                    },
                    emptyList()
                )
            }
        }
    }

    @PreAuthorize("(hasRole('USER') and @mySecurityService.moreThan10(principal))or hasAnyRole('EDITOR','ADMIN')")
    override fun addOne(book: BookDTO): Unit {
        books.addOne(book)
        }

    override fun getOne(id: Long): BookListDTO {
    var book = books.getOne(id).orElseThrow { ResponseStatusException(HttpStatus.NOT_FOUND, "Book not found ${id}") }
print(SecurityContextHolder.getContext().authentication.principal)
        if (SecurityContextHolder.getContext().authentication.principal != "anonymousUser") {
            return book.let {
                BookListDTO(
                    it.id,
                    it.title,
                    it.authors.map { AuthorsBookDTO(it.name) },
                    it.reviews.map { ReviewBookDTO(it.id, it.review, it.rating, it.user.username) }
                )
            }
        } else {
                return book.let {
                    BookListDTO(
                    it.id,
                    it.title,
                    it.authors.map { AuthorsBookDTO(it.name) },
                    emptyList()
                    )
             }
            }
    }

    @PreAuthorize("@mySecurityService.canUpdateBook(principal, #id) or hasRole('ROLE_ADMIN')")
    override fun updateOne(id: Long, elem: BookDTO) {
        books.updateOne(id,elem)
    }
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    override fun deleteOne(id: Long) =
        books.deleteOne(id)


    override fun getReviews(id: Long): List<ReviewBookDTO> =
        books.getReviews(id).map{
            ReviewBookDTO(
                it.id,
                it.review,
                it.rating,
                it.user.username)
        }


    override fun addReview(id: Long, review: ReviewDTO): List<ReviewBookDTO> =
        books.addReview(id,review).map{
            ReviewBookDTO(
                it.id,
                it.review,
                it.rating,
                it.user.username)}


    override fun getReviewOfBook(id: Long, rid: Long): ReviewBookLongDTO =
        books
            .getReviewOfBook(id,rid)
            .orElseThrow{ResponseStatusException(HttpStatus.NOT_FOUND, "Book or Review not found ${id}")}
            .let{
                ReviewBookLongDTO(
                    it.review,
                    it.rating,
                    it.user.username,
                    id
                )

            }
    @PreAuthorize("@mySecurityService.canUpdateReview(principal, #rid) or hasRole('ROLE_ADMIN')")
    override fun updateReviewOfBook(id: Long, rid: Long, review: ReviewDTO) {
        books.updateReviewOfBook(id,rid, review)
    }

    @PreAuthorize("@mySecurityService.canUpdateReview(principal, #rid) or hasRole('ADMIN')")
    override fun deleteReviewOfBook(id: Long, rid: Long) {
        books.deleteReviewOfBook(id,rid)
    }
}