import React from 'react';
import logo from './logo.svg';
import './App.css';
import { Route, Routes } from 'react-router-dom';
import HomePage from './Components/HomePage';
import NavBar from './Components/NavBar/NavBar';
import SignIn from './Components/SignIn/SignIn';
import BookList from './Components/BookLists/BookList';

function App() {
  return (
    <>
    <NavBar/>
    <Routes>
      <Route path="/" element={<HomePage />}/>
      <Route path="/signin" element={<SignIn/>}/>
      <Route path="/anonymous" element={<BookList/>}/>  
      <Route path="/registered" element={<BookList/>}/>  
      <Route path="/admin" element={<BookList/>}/>   
    </Routes>
    </>
  );
}

export default App;
