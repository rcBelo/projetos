import { useState, useEffect, ChangeEvent } from 'react';
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { useLocation } from 'react-router-dom';
import { Modal, TextField } from '@mui/material';
import { FiChevronRight, FiChevronLeft } from 'react-icons/fi'
import Rating from '@mui/material/Rating';


const theme = createTheme();
interface Review {
  text: string,
  rating: number,
  date: number
}

interface Book {
  images: string[];
  title: string;
  author: string;
  summary: string;
  rating: number;
  reviews: Review[]
}
const style = {
  position: 'absolute' as 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 400,
  overflow:'scroll',
  bgcolor: 'background.paper',
  border: '2px solid #000',
  boxShadow: 24,
  p: 4,
};
export default function BookList() {

  const location = useLocation()
  const userType = location.pathname.replace("/", "")
  const [books, setBooks] = useState<Book[]>([])
  useEffect(() => {
    setBooks(require("../../books.json"))
  }, [])
  const [rating, setRating] = useState<number>(0);
  const [name, setName] = useState<string>("");
  const handleRatingChange = (event: any) => {
    setRating(parseInt(event.target.value));
  };
  const handleNameChange = (event: any) => {
    setName(event.target.value);
  };
 
  const [open, setOpen] = useState<{ openModal: boolean, index: number }>();
  const showModal = (index: number) => {
    setOpen({ openModal: true, index: index })
  }
  
  const [showAddReview, setAddReview] = useState<boolean>(false);
  const [showListReview, setListReview] = useState<boolean>(false);

  const addReview = () => {
    setAddReview(true)
    setListReview(false)
  }
  const showReview = () => {
    setListReview(true)
    setAddReview(false)
  }
  const [valueR, setValueR] = useState<number>(0);
  const [valueT, setValueT] = useState<string>("");
  const changeText = (e:any) =>{
    setValueT(e.target.value)
  }
  const dateConverter = (date:number) =>{
    var d = new Date(date);
    return d.toLocaleDateString()
  }
  const confirmReview = () => {
    const newList = books.map((item,index) => {
      if (index === open?.index) {
        const updatedItem = {
          ...item,
          reviews: [...item.reviews, {text:valueT, rating:valueR, date:Date.now()}],
        };

        return updatedItem;
      }

      return item;
    });

    setBooks(newList);
  }
  const [orderBy, setOrderBy] = useState<string>("Date")
  const handleOrderChange = (e:any) =>{
    setOrderBy(e.target.value)
  }
  useEffect(()=>{
    if(orderBy === "Date" && open && open.index){
      setBooks(prev => {
        let newVec = [...prev]
      newVec[open.index].reviews.sort(function(a, b){return b.date-a.date})
      return newVec
      })
    }
      else if(open && open.index){
        setBooks(prev => {
          let newVec = [...prev]
        newVec[open.index].reviews.sort(function(a, b){return b.rating-a.rating})
        return newVec
        })
      }
  }, [orderBy,books,open])


  const closeModal = () => {
    setOpen({ openModal: false, index: 0 })
    setListReview(false)
    setAddReview(false)
  }

  const deleteReview = (ind:number) => {
    if(open ){
    setBooks(prev => {
      let newVec = [...prev]
    newVec[open.index].reviews.splice(ind, 1)
    return newVec
    }) 
  }
  }
  const [imageToShow, setImageToShow] = useState<number>(0)
  useEffect(() => {
    setInterval(() => {
      setImageToShow(prev => prev + 1)
    }, 10000);
  },[])


  return (
    <ThemeProvider theme={theme}>
      <main>
        {userType !== "anonymous" &&
          <div>
            <p>
              Name:
              <input onChange={handleNameChange} type="search"></input>
            </p>
            <p>Rating:
              <select style={{ borderRadius: "7px", width: "auto", marginLeft: "10px", fontSize: "20px" }} onChange={handleRatingChange}>
                <option selected value={0}>Show All</option>
                <option value={1}>1</option>
                <option value={2}>2</option>
                <option value={3}>3</option>
                <option value={4}>4</option>
                <option value={5}>5</option>
              </select>
            </p>
          </div>

        }
        <Container sx={{ py: 8 }} maxWidth="md">
          <Grid container spacing={4}>
            {books.map((book, index) => (
              rating !== 0 ? book.rating === rating && book.title.toLowerCase().includes(name.toLowerCase()) &&
                <Grid item key={index} xs={12} sm={6} md={4}>
                  <Card
                    sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}
                  >
                    <CardMedia
                      sx={{ height: '30em', width: '100%' }}
                      component="img"
                      image={book.images[Math.round(imageToShow%book.images.length)]}
                    />
                    <CardContent sx={{ flexGrow: 1 }}>
                      <Typography gutterBottom variant="h5" component="h2">
                        {book.title}
                      </Typography>
                      <Typography>
                        {book.author}
                      </Typography>
                    </CardContent>
                    <Button onClick={() => showModal(index)} size="small">View More</Button>

                  </Card>
                </Grid> : book.title.toLowerCase().includes(name.toLowerCase()) && <Grid item key={index} xs={12} sm={6} md={4}>
                  <Card
                    sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}
                  >
                    <CardMedia
                      sx={{ height: '30em', width: '100%' }}
                      component="img"
                      image={book.images[Math.round(imageToShow%book.images.length)]}
                    />
                    <CardContent sx={{ flexGrow: 1 }}>
                      <Typography gutterBottom variant="h5" component="h2">
                        {book.title}
                      </Typography>
                      <Typography>
                        {book.author}
                      </Typography>
                    </CardContent>
                    <CardActions>
                      {userType !== "anonymous" &&
                      <Button onClick={() => showModal(index)} size="small">View More</Button>
}
                    </CardActions>
                  </Card>
                </Grid>
            ))}
          </Grid>
        </Container>
        <Modal open={open?.openModal || false} onClose={closeModal}>
          <Box  sx={style}>
            {open &&
              <>
                <Typography id="modal-modal-description" sx={{ mt: 2 }}>
                  {books[open.index].summary}
                </Typography>
                <Button onClick={addReview}>Add Review</Button>
                <Button onClick={showReview}>Show Reviews</Button>
                {showListReview && <p>Order by:
                <select style={{ borderRadius: "7px", width: "auto", marginLeft: "10px", fontSize: "20px" }} onChange={handleOrderChange}>
                  <option value="Date">Date</option>
                  <option value="Rating">Rating</option>
                </select>
              </p> }
                {showListReview 
                && books[open.index].reviews.map((review, index) => (
                  <>
                    <Typography id="modal-modal-description">
                      Rating: {review.rating}
                    </Typography>
                    <Typography id="modal-modal-description">
                      Date: {dateConverter(review.date)}
                    </Typography>
                    <Typography id="modal-modal-description">
                      {review.text}
                    </Typography>
                    {userType === "admin" &&
                    <Button onClick={() => deleteReview(index)}>Delete Review</Button>}
                  </>
                ))
                }
                {showAddReview && <div>

                  <TextField onChange={changeText} multiline></TextField>
                  <Rating
                    name="simple-controlled"
                    value={valueR}
                    onChange={(event, newValue) => {
                      if (newValue)
                        setValueR(newValue);
                    }}
                  />
                  <Button onClick={confirmReview}>Confirm</Button>
                </div>}

              </>
            }
          </Box>
        </Modal>
      </main>
    </ThemeProvider>
  );
}

/*
<img style={{width:'390px', height:'550px'}} src={books[open.index].images[imageIndex]}/>
                        <FiChevronLeft />
                        <FiChevronRight/>
*/
