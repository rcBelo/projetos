# -*- coding: utf-8 -*-
"""
Created on Fri Oct 21 00:44:58 2022

@author: Joao Palma 55414
         Ruben Belo 55967
"""
from tp1LinearRegression import doLR
from tp1NaiveBayes import doNB



doLR()
doNB()



